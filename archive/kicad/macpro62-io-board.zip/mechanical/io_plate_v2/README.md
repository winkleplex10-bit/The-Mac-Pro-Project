> **Update 2026-10-04 ≈ 15:55 ET: ear-1 clash fixed on the board side (Aidan; not pushed).** The main-board HDMI clamp post **H25 moved (50.82, 111.0) → (53.60, 114.35)**; see the IOB README and `kicad/macpro62-io-board/tools/hdmi_post_search.py`. `build_plate.py` checks now pick the HDMI post nearest the button and assume a **countersunk M2** (`--clamp-head pan` for the old pan head). Every variant, preview, DXF and check was regenerated; plate geometry is unchanged.
>   | `button.check.hdmi_clamp` | csk M2 (default, top 15.26) | pan M2 (top 16.86, for reference) |
>   |---|---|---|
>   | ear-1 M1.4 head: plan / vertical | **0.83** / 0.26 | 0.83 / −1.34 |
>   | ear-1 Ø3.0 boss: plan / vertical | **0.63** / 1.68 | 0.63 / 0.08 |
>   | carrier ring: plan / vertical (island at the frame plane) | **2.59** / 1.22 | 2.59 / −0.38 |
>   | carrier ear-1 lug (assumed 3.0-wide) | 0.63 | 0.63 |
>   | clamp-plate edge (head + 0.4) to the ear-1 head | 0.43 plan / 0.26 vertical | same |
>   | frame (head over the bar between the HDMI slot and the AC opening; frame back 15.83) | **0.57 below** | **−1.03 (clash)** |
>   | rib / collar | 3.95 / 2.88 in plan | same |
>   - The carrier vs HDMI head item (−0.06, 13:10 ET) and the ear-1 head clash (15:30 ET) are **resolved**. The ear-2 head over the traced frame leg (−1.01) is **still open**.
>   - Wall check unchanged: general 1.343–1.382, exceptions ≥ 0.404.

> **Update 2026-10-04 ≈ 15:30 ET: prints-vs-stock scan, wider shield, larger corner radius, Ø5.3 audio, ear BOSSES (Aidan; not pushed).** `build_plate.py`; every variant, preview, DXF and check was regenerated; new comparison overlay `io_plate_v2_A0_scan_compare.png`.
> - **Scan and method** (`scan_prints/`): 200 dpi flatbed, 3 printed plates (P1 top, P2, P3) and the stock plate, all inner face down, with a cm ruler. Ruler scale 7.891 px/mm horizontal / 7.875 vertical. Each plate is warped into back-view model coordinates and **registered on its own port openings**: Y scale + offset (rms 0.05–0.10 mm, 12–16 openings), X mean shift.
>   - The lamp shadow lies along model X (+1.2–1.8 mm on one side of every edge), so X widths come from the sharp edge and the shadow-free edge only. Y measurements are shadow-free.
>   - **None of the 3 prints is the current (−1.0) version.** P1 and P2 have the corner screws at the +1.0 (10:30 ET) positions; P3 has them at the original positions.
> - **Changes:**
>   | # | Change | Value used | Measured from the scan | Confidence |
>   |---|---|---|---|---|
>   | 1 | Corner screws toward the audio end | **0 additional; total stays `SCREW_SHIFT_Y` = −1.0** (SCR_T± Y 148.95, SCR_B± Y 13.70) | Stock rings (model Y): 148.84 / 149.09 at the AC end, 13.51 / 13.41 at the audio end. Prints read P1 151.0 / 15.5, P2 151.0 / 15.3, P3 ≈ 150.0 / 14.3, i.e. the prints are **+2.0 (P1/P2) and +1.0 (P3) toward the AC end** vs stock. After the print-read bias (bottom rings read 0.2–0.4 low), the stock is 148.9 / 13.5–13.8, so the current −1.0 matches within 0.2 (top) / 0.3 (bottom). X pitch: stock 45.35, prints 45.0 (model 45.1), within the read error, unchanged | medium-high |
>   | 2 | Shield width | **PL_W 51.9 → 52.7 (+0.8)**, symmetric about X 53.19 (`SHIELD_W_ADD`) | Stock 53.1–53.2 vs prints 52.4 ± 0.15 (printed from 51.9): stock − prints = **+0.75 ± 0.3**. A hint of up to +0.4 more on +X only is not applied | medium |
>   | 2 | Corner fillets | **PL_R 11.5 → 12.8** (`PL_R_NEW`) | Shadow-free top corners: stock 12.83 / 12.49; prints 10.3–12.2 (mean 11.2, from R 11.5) | medium |
>   | 3 | Audio holes | **AUD_D 4.8 → 5.3 (+0.5)** | Stock hole Ø4.8 ± 0.3 (blurred, in Y), prints 4.9–5.1. The scan neither supports nor contradicts a different value, so Aidan's +0.5 is used | medium-low |
>   | 4 | Power-button ear features | **Bosses** (`BTN_EAR_MODE = "boss"`; `--ear-posts` restores the posts): **Ø3.0 × 1.0** (`BTN_BOSS_OD/H`, `--boss-h`), 0.25 chamfer, **pilot Ø1.1 × 1.9** with a lead-in, 0.5 skin at the outer face. The carrier sits on the bosses; **M1.4 × 2.5 thread-formers** (head Ø2.6 × 0.9, carrier 0.4 assumed) go through the Ø1.8 ear holes (0.2/side). Thread engagement 1.98, pilot wall 0.95. Ø3.0 cannot pass the Ø1.8 holes, hence bosses | geometry high; boss height / carrier t **assumed** |
>   | — | Length / ends | unchanged | Stock 163.24 vs prints 163.3; ends within 0.2 of the model | high |
> - **Ear-boss clearances** (`button.check.posts[].screw`):
>   | Item | Boss 1 (49.65, 113.53) | Boss 2 (36.23, 103.03) |
>   |---|---|---|
>   | Boss to collar | fused (web −0.44) | fused (−0.52) |
>   | Boss to frame opening (plan) / tip to frame front | 0.45 / 0.17 | **−1.21** (over frame material) / 0.17 |
>   | Boss to HDMI clamp-post M2 head (50.82, 111.0) | 0.61 overlap in plan, 0.08 vertical | — |
>   | **M1.4 head** (depth 1.52–2.42 behind the inner face) | **⚠ vs the HDMI clamp-post head: 0.41 overlap in plan, −1.34 vertical → CLASH** | **⚠ lands on the frame BIG_L leg: margin −1.01, frame at depth 1.17–2.17 → CLASH** |
>   - **Fix options** ((a) done 15:55 ET: H25 → (53.60, 114.35), countersunk M2; ear 1 clears by 0.83 / boss 0.63, see above)**:** (a) move the HDMI clamp post radially to about **(52.3, 111.6)** (≥ 9.9 from the button centre, ≥ 3.35 from ear 1): a board change, suggested, not made; (b) heat-stake or glue the carrier instead of the ear-1 screw; (c) for ear 2, check the frame-trace BIG_L leg edge (X 35.94). The stock carrier's −X edge also traces 0.7 over the frame, which suggests the trace is about 1 mm off there. Measure on a print before relying on screw 2.
>   - Still open from 13:10 ET (carrier part resolved 15:55 ET): the carrier has −0.06 room over the HDMI clamp-post head if the button island sits at the frame plane. SCR_B− overlaps J31 by 1.34 and SCR_T− overlaps BT1 by 0.39 in plan only (≥ 7.5 vertical).
> - **Re-checked after the change:**
>   - Corner-screw edge margins (csk outer / inner): top 1.65 / 1.87, bottom 2.18 / 2.40; all `ok_plate`.
>   - Audio Ø5.3: flex through-margin 0.39 (AUD_H) / 1.02 (AUD_O); jack-nose margin 0.04 / 0.67.
>   - Collar to AC 2.21; key-tab corners to the plate edge 7.84.
>   - `check_thickness`: general wall 1.343–1.382 on all 4 variants, exceptions ≥ 0.404 (countersinks). No LED conflicts.
> - **Other openings vs stock** (opening-registered; positions agree within ±0.1 except HDMI +0.21 and AC −0.19 in Y). **No change made: all differences are by design or below the read error.**
>   | Opening | Stock (scan) | Model | Note |
>   |---|---|---|---|
>   | C1–C6 | Thunderbolt/mDP openings ≈ 6.5 × 5.2 visible | USB-C 9.6 × 4.0 R1.8 | intentional (USB-C ports) |
>   | A1–A4 | ≈ 11.0–11.6 × 5.4 visible | 14.0 × 6.0 | intentional (plug overmoulds) |
>   | HDMI | ≈ 13.0 × 5.3 | 15.6 × 5.7 | intentional (flex cut-out / shell); stock centre +0.21 in Y |
>   | ETH1/ETH2 | Y extent 10.0 / 9.9 (the prints read +0.4 over their model sizes, so the stock is ≈ 9.6) | 13.0 × 10.4 / 10.7 | model ≈ 0.8–1.1 taller than stock; intentional plug/latch clearance, positions within 0.1 |
>   | AC | Y extent ≈ 23.6 | 24.65 | possibly ≈ 1 mm larger than stock; left as is (stock window shape) |
> - **⚠ Findings to confirm (not changed):**
>   1. **The stock button cap/collar centre is at ≈ (43.08, 107.1), about 1.0 lower in Y than the model / flex-trace button (108.11).** The stock ear features are also about 1 mm low: (50.4, 112.6) / (36.7, 101.8) vs the model (49.65, 113.53) / (36.23, 103.03). Scan 83f0b85e showed the same offset (+1.05 re-centre). Not moved, because the plate must line up with the flex dome, which was traced at 108.11. Check on a print with the flex fitted (M-IOPB8).
>   2. **The stock collar reads OD ≈ 13.5 / ID ≈ 12.0** in this inner-face view (model OD 15.0 / ID 12.4); medium-low confidence. An OD 13.5 collar would separate the bosses from the collar (M-IOPB2).

> **Update 2026-10-04 ≈ 13:10 ET: power-button ring is a RAISED COLLAR, and the corner screws are moved the other way (Aidan; not pushed).** `build_plate.py`; every variant, preview, DXF and check was regenerated.
> 1. **Collar replaces the 0.5 recess** (Aidan 12:58 ET: the ring is a raised collar on the inner face that lines the button cap up with the flex dome). The pocket cut is gone, so the **full 1.4 wall is back** under the former recess (probed 1.39–1.40 just outside the collar, 2.2 through it).
>    | Feature | Size | Confidence |
>    |---|---|---|
>    | `BTN_COLLAR` raised annulus around the Ø12.4 opening, constant height normal to the curved inner face | **OD 15.0 / ID 12.4 / H 0.80** (wall 1.3). The ID equals the opening, so the cap gets one straight guide bore 1.4 + 0.8 = 2.2 long | raised: confirmed (Aidan). OD medium (scan ring Ø15.1 ± 0.3). ID **assumed** (= opening; the stock cap/carrier OD is not measured). Height **assumed** |
>    | `BTN_KEY` | **tab** on the collar, same height, 2.6 wide, r 7.0–9.8, at 140° (back view). `BTN_KEY_MODE = "gap"` turns it into a keyway slot through the collar wall; `"none"` removes it | medium-low (scan notch only) |
>    | ~~ear posts~~ **(superseded 15:30 ET: Ø3.0 bosses + M1.4 screws, see above)**, rib | unchanged: Ø1.6 × 1.0 (core Ø0.8), 0.5 × 5.6 × 1.0 | as before |
>    - **Height parameter:** `BTN_COLLAR_H` = `BTN_FLEX_DEPTH` − `BTN_COLLAR_CLR` = 1.00 − 0.20 = **0.80**; override with `--collar-h X`. The frame is 1.17 behind the inner face (`BTN_FRAME_GAP`). The collar end stops **0.37 short of the frame plane**. If the button island sits back at the frame plane (Aidan's model, plate-side face assumed at depth 1.00), there is **0.20** between the collar end and the flex, so the dome is not loaded.
>    - **Caution, if the flex is PSA-bonded flat instead:** the collar end would lift the button island by 0.75. Leave the flex unbonded within about 3 mm of the collar, or set `--collar-h` lower.
> 2. **Corner screws moved −1.0 in Y from the ORIGINAL scan positions**, i.e. toward the audio-jack end. That is 2.0 from the 10:30 positions, so the 10:30 move is reverted and overshot by 1.0. `SCREW_SHIFT_Y` = −1.0, pitch unchanged:
>    SCR_T− (30.64, **148.95**), SCR_T+ (75.74, **148.95**), SCR_B− (30.64, **13.70**), SCR_B+ (75.74, **13.70**).
> - **Collar clearances** (`button.check.collar` in `io_plate_v2_A0_features.json`):
>   | To | Clearance |
>   |---|---|
>   | AC / ETH2 / HDMI openings | 2.21 / 3.67 / 5.53 (key-tab corners to AC 3.04, to the plate edge 7.44) |
>   | button LEDs (inside the bore) | 0.01 (LED far corner r 6.19 vs bore r 6.20; the cap is the light pipe). Other LEDs ≥ 4.83 from the collar |
>   | flex | collar OD 0.29 inside the carrier ring (r 7.79), so it bears on the carrier ring, not the flex body. Collar to the flex-slot edge (X 50.83) 0.31, to the rib 0.46 |
>   | ear posts **(superseded 15:30 ET)** | post-to-collar web 0.26 / 0.18; 0.10/side in the Ø1.8 ear holes; tips 0.17 short of the frame front |
>   | frame | collar (−0.42) and tab (−0.43) lie over frame material at −X in plan, but end 0.37 short of the frame plane |
>   | HDMI clamp-post M2 head (50.82, 111.0), top 16.86 above the board (Ø3.8 pan head, k 1.6 assumed) | collar: 1.08 overlap in plan, **0.30 vertical**. BTN_POST_1: 0.09 plan / 0.08 vertical. Rib: 0.21 in plan |
> - **⚠ Finding: the button carrier vs the HDMI clamp-post head.** If the button island sits at the frame plane, the carrier behind it has **−0.06** of room over that M2 head (it clashes). If the flex is flat, it has 0.89. The carrier's −X edge (X 35.24) also lies 0.7 over frame material. Possible fixes: move the HDMI clamp post off the carrier footprint, use a low/wafer head (k ≤ 1.0), or confirm the stack via M-IOPB6/7.
> - **Ear posts (superseded 15:30 ET):** if the island is at depth 1.0, the 1.0 posts only just reach the flex face. Lengthening them is limited because BTN_POST_2 overlaps the frame leg edge by 0.51 in plan.
> - **Corner screws re-checked** (csk default; `pt` in brackets; minimums: edge ≥ 0.6, flex ≥ 0.1, neck ≥ 0.3, opening ≥ 1.0):
>   | Screw | Outer csk-edge / inner edge | Flex | Nearest opening | Light pad / LED | Frame-trace corner hole offset (was) | Board parts in plan (fastener r 2.0 below the frame, lowest 12.69 above the board; pt 13.18) |
>   |---|---|---|---|---|---|---|
>   | SCR_T− | 1.57 / 1.80 (pt 1.80) | 33.5 | AC 8.03 | 35.6 | 2.87 (3.09) | **BT1 −0.39** (was +1.61); coin cell 3.25 |
>   | SCR_T+ | 1.57 / 1.80 (pt 1.80) | 31.9 | AC 7.88 | 32.7 | 1.95 (3.14) | L41 1.15 |
>   | SCR_B− | 1.77 / 2.00 (pt 2.00) | 4.17 | AUD_H 8.85 | 6.84 | 0.64 (1.52) | **J31 −1.34** (was +0.66); J28 0.82; flex neck 12.6 |
>   | SCR_B+ | 1.78 / 2.00 (pt 2.00) | 3.63 | W_AUD_O 8.72 | 6.48 | 1.43 (2.92) | J28 5.39 |
>   - All 4 screws are `ok_plate` in both modes. The top countersinks moved away from the corner arc (0.92 → 1.57). The bottom pair's edge margin is set by the side edge (X) and is unchanged. Their distance to the bottom edge in Y is still 18.2.
>   - Countersink wall: `check_thickness` exceptions are unchanged at ≥ 0.367 (csk) / 0.434 (pt). The general wall is 1.341–1.466 on all 4 variants.
>   - All 4 screws are now closer to the 100 dpi frame-trace corner holes. That is consistent with Aidan's correction, but the spigot Ø2.8 only enters a Ø3.16–3.50 hole within 0.18–0.35 of its centre, so M-IOS1 is still needed.
>   - **Flag (below the plan ≥ 0 rule):** SCR_B− overlaps the **J31** courtyard by 1.34 and SCR_T− overlaps the **BT1** courtyard by 0.39, in plan only. The washer and nut sit 12.69 above the board, J31 is about 2.0 tall and BT1 about 4–5, so there is ≥ 7.5 vertical clearance and no physical clash is expected. The flex tail into J31 also leaves the plate 12.6 away. Confirm the J31 flex-tail route and the BT1 cell-swap access on the print.
> - **Measure:** M-IOPB1 (cap/carrier OD, which sets the collar ID), M-IOPB2 (collar height/Ø), M-IOPB3 (key tab or gap), M-IOPB6/7 (carrier thickness, flex stack at the button), and M-IOS1.

> **Update 2026-10-04 ≈ 12:35 ET: power-button features built into the plate, and clamp post H21 moved (Aidan; not pushed).** `build_plate.py` (`BUTTON_FEATURES`, on by default; `--no-button` turns it off), new `button_closeup.py`. Every variant, preview, DXF and check was regenerated.
> - **Evidence.** In the outer-face scan 83f0b85e the plate is translucent enough to show the inner-face features. Around the Ø11.9 button hole (scan) there is a lighter ring out to Ø15.1 ± 0.3 (thinner wall, so a counterbore) with a key notch at about 140° (back view). There is a "crater" (ring Ø≈2.5 with a dark Ø≈1.1 core) at **both** carrier-ear holes. There is also a straight line along the 0.8 slot between the carrier ring and the flex body. The flex scan (06ea8deb) shows the carrier: a black ring Ø15.57 with 2 diagonal ear lugs (Ø1.8 holes) and a small key tab, with the dome and 2 LEDs on the scanned (board-facing) side. The scan is registered about (−0.5, −1.0) off the flex trace, so **every position is taken from the flex trace**. There is no inside-face scan; the phone splat scan cannot resolve heights (README in `io_cover_scan`).
> - **Added (inner face, at the flex button (43.02, 108.11)):**
>   | Feature | Size | Confidence |
>   |---|---|---|
>   | ~~`BTN_POCKET` keyed counterbore~~ **(superseded 13:10 ET: raised collar, see above)** around the Ø12.4 opening (button-cap flange seat, anti-rotation) | Ø15.0 × 0.50 deep, wall left 0.90 | position high; Ø medium; depth **assumed** |
>   | `BTN_KEY` key notch, same depth | 2.6 wide, r 7.0–9.8, at 140° (back view) | medium-low (scan only) |
>   | ~~`BTN_POST_1/2` ear posts~~ **(superseded 15:30 ET: Ø3.0 bosses)** through the carrier ear holes; double as the retainer mounts (heat-stake, or an M1.0 thread-forming screw in the core) | Ø1.6 × 1.0 (radial), 0.10/side in the Ø1.8 holes; core Ø0.8 × 1.9 (0.5 skin left at the outer face; `BTN_POST_CORE_D = 0` makes them solid) | position high (flex trace ±0.15 + scan); length/core medium-low |
>   | `BTN_RIB` locating rib in the 0.8 flex slot | 0.5 × 5.6 × 1.0, X 51.23, Y 103.3–108.9 (0.15/side in the slot) | medium-low |
>   | Light / LED | No separate light pipe in the plate. The 2 button LEDs sit inside the Ø12.4 opening footprint (far corner r 6.19, margin 0.01), so the clear cap is the light pipe. | LED positions high |
> - **(Superseded 15:30 ET: the ear features are now Ø3.0 bosses under the carrier.)** **No tall screw bosses.** None fits outside the flex: the flex covers the frame BIG_L leg opening, the AC opening is 2.2 above the pocket, and the frame sits 1.17 behind the inner face everywhere else. So the ear posts are the retainer mounts.
> - **Checks** (`button` in `io_plate_v2_A0_features.json`):
>   - pocket to the AC / ETH2 / HDMI openings: 2.21 / 3.67 / 5.53; key corners to AC 3.04, to the plate edge 7.44;
>   - post web to the pocket 0.26 / 0.18;
>   - post tips 0.17 short of the modelled frame front. BTN_POST_2 overlaps the frame leg edge by 0.51 in plan, which is why it stops at 1.0;
>   - BTN_POST_1 to the main-board HDMI clamp-post M2 head (50.82, 111.0): **0.09 in plan, 0.08 vertical** (pan head k 1.6 assumed, top 16.86). Tight but clear. The rib stops 0.21 short of that head;
>   - no LED conflicts.
> - **Wall check:** general 1.341–1.466 (STL faceting, unchanged elsewhere). Local exceptions: pocket floor 0.90 and 0.50 over the post cores. Existing exceptions unchanged: countersinks ≥ 0.37 and seats/bosses up to 2.39.
> - **Foam DXF:** now has Ø2.2 holes at the two ear posts **(15:30 ET: Ø3.1)**.
> - **New DXF layer:** `BUTTON_INNER_FEATURES` (back and front view).
> - **Close-up:** `io_plate_v2_A0_button_closeup.png` (plan with scan underlay + sections A-A through both posts and B-B along X + 3D inner face).
> - **H21 moved:** main-board clamp post C upper H21 (53.19, 70.80) → **(53.19, 69.80)** in `kicad/macpro62-io-board/tools/modules_geom.py` (`POSTS`), so `modules.json`, the PCB and this plate follow. Distance to SCR_C1 is now 5.70, so the web between the clamp-plate Ø5.0 hole and the Ø3.8 post is **0.3 → 1.3**, and `clamp_post_margin` is 0.80 → 1.80. modules_geom 114/114 checks OK. Main-board DRC: 0 violations, 0 unconnected; schematic untouched.
> - **Measure on the stock plate (M-IOPB1–7):**
>   1. Button hole Ø on both faces; stock cap OD, flange OD/thickness and key tab.
>   2. Is the Ø≈15 ring a recess or a raised collar, and what is its depth/height and exact Ø?
>   3. Key notch angle, width and radial extent.
>   4. Ear features: pin or screw boss? OD, bore, height above the inner face; heat-staked or screwed (screw size and length)?
>   5. Rib along the flex slot: present? Thickness, length, height, X.
>   6. Carrier: thickness at the ring and the ear lugs, and which flex face it, the dome and the LEDs are on.
>   7. What backs the dome (retainer/bracket under the ears? frame tab?), its thickness, and the plate-inner-face-to-frame gap at the button (1.17 assumed).

> **Update 2026-10-04 ≈ 10:35 / 11:15 ET (Aidan's test print; not pushed).** Applied in `build_plate.py` (`SCREW_SHIFT_Y`, `CENTRE_TRIM`); every variant, preview, DXF and check regenerated.
> 1. ~~**All 4 corner mounts +1.0 in Y**~~ **(superseded 13:10 ET: wrong direction; now −1.0 from the scan positions, see above)**, i.e. toward the plate's **top** edge (the end away from the audio jacks at Y ≈ 19). Pitch unchanged (45.1 × 135.25):
>    SCR_T− (30.64, **150.95**), SCR_T+ (75.74, **150.95**), SCR_B− (30.64, **15.70**), SCR_B+ (75.74, **15.70**).
>    - Outer edge margin of the top Ø3.25 countersinks 1.29 → **0.92** (rule ≥ 0.6; inner 1.14). Bottom row unchanged at 1.77 / 1.78.
>    - SCR_B− now clears J31 in plan (−0.34 → **+0.66**); SCR_T− to BT1 0.61 → 1.61. All `ok_plate`.
>    - They now sit 1.5–3.1 from the 100 dpi frame-trace corner holes (were 0.6–2.8); that trace was already low confidence (M-IOS1), the print wins.
>    - Not changed: boss height (spigot 0.8 below the inner face, `CORNER_GAP` 0). If "up" meant taller bosses, that is `SPIGOT_L` / `CORNER_GAP`.
> 2. **Centre screw = SCR_C1 only** (corrected ≈ 11:15 ET; the ≈ 10:35 build had removed the wrong one). SCR_C1, upper, (53.76, 75.47): M1.6 in frame hole C1 Ø3.17, post Ø2.6, csk Ø3.25 / Ø1.8 clearance (pt: Ø1.30 pilot), washer Ø4. **Post 1.0 shorter** (`CENTRE_TRIM`): 1.97 → **0.97** below the inner face (0.17 to the modelled frame front + 0.8 spigot), local wall 3.37 → 2.37. Margins unchanged: flex hole 0.21, foam 0.71, frame hole 0.15, nearest opening C4 3.54 (pt 3.87), LED (53.3, 70.9) 2.69, C4 shell 2.67.
> 3. **SCR_C2 removed** (lower, (53.45, 58.27): the stock alignment post we don't have). Flex hole HOLE_C2 is left free. The Ø7.0 clamp-plate hole and the H13-standoff conflict no longer apply.
> - **Still open at SCR_C1 (module clamp plate C, top 15.26 above the board):** the fastener ends 14.73 above the board (pt variant 15.23), so the plate still needs a **Ø5.0 clearance hole at SCR_C1**. The C clamp-post M2 screw at **(53.19, 70.80)** (H21) is 4.70 away centre-to-centre, which leaves only ≈ 0.3 of web between that hole and the post (Ø3.8). Move H21 to Y ≤ 69.8, or merge the hole into a slot. In plan the fastener clears the post by 0.8; the H21 SMT nut on the board sits right under its edge (0.02) but far below it in height.
> - **Wall check** (`check_thickness.py`): general 1.341–1.466 (STL faceting, unchanged); port seats / bosses max 3.37 → 2.39.
> - **Print file:** `io_plate_v2_A0.stl` (csk default, ETH2 open). Variants: `_eth2blank`, `_screwpt`, `_tilt12p5` (.step / .stl).

> **Update ≈ 16:25 ET: centre screws are now the PRIMARY plate→frame fixing (Aidan, 16:14 ET: "the couple of holes near the centre definitely have screws"). The 4 corner M1.6 screws below are now secondary.**
>
> *Re-check of the centre features.* Scan 83f0b85e, `io_plate_v2_A0_screw_candidates.png`. The centre features are soft in the scan (out of the focus plane), so all of these are visual reads, ±0.5.
>
> | # | Scan | Flex 821-2222 hole (mirrored trace) | Frame trace (mirrored) | Confidence |
> |---|---|---|---|---|
> | K9 | soft ring Ø≈2.4, core ≈1.0, at (53.2, 76.1) | HOLE_C1 Ø3.30 at (53.64, 75.53) | HOLE_C1 Ø3.17 at (53.89, 75.41) | **high** that a screw is here (Aidan + 3 sources); position ±0.3 |
> | K10 | dark disc Ø≈4.5–5 with bright arcs, at (53.0, 58.6) | HOLE_C2 Ø5.08 at (53.46, 58.16) | HOLE_C2 Ø4.84 at (53.44, 58.38) | **high**; ±0.3 |
> | K11 | faint arc + bright blob at (52.6, 19.3) | PIN_C3 Ø5.67 at (53.44, 19.27) | PIN_C3 Ø3 at (52.33, 19.23), "dark ring, bright centre" | **low**: may be a light pipe or pin; built only with `--c3` |
> | — | small ring at (47.7, 112.2) | BTN_EAR_1 Ø1.8 | — | flex button-carrier locating ear, not a screw |
>
> The three flex holes are larger than the frame holes. They are the clearance holes the stock posts pass through.
>
> **How the plate reaches the frame.** The frame is not 16.5–18 mm away; that is the plate-to-board-top gap. Plate inner face → PSA 0.05 + flex 0.12 + foam 1.0 = **1.17** → frame front face.
> - At the crown: frame front at 18.0 − 1.17 = 16.83 above the board top, frame back at 15.83.
> - The module model has `frame_back_height` 15.50–15.56 at the port columns; this is the same concentric frame.
>
> So the stock plate reaches the frame with a **post on the inner face**:
> - It runs 1.17 to the frame front, plus 0.8 into the frame hole, which is shorter than the 1.0 frame so the washer clamps the frame.
> - Post length 1.97 below the inner face; **local wall 3.37** (the only local exception besides the seats and corner bosses).
> - If M-IOF2 shows a different frame height, set `CENTRE_GAP` = D0(x) − frame-front height.
>
> **Design** (`CENTRE_SCREWS` in `build_plate.py`). Positions are the midpoint of the flex-hole and frame-hole centres.
>
> | Screw | Position | Post | Radial margins | csk (default) | pt (`_screwpt`) |
> |---|---|---|---|---|---|
> | **SCR_C1** | (53.76, 75.47) | Ø2.6 | 0.21 in the flex hole, 0.71 in the foam hole, 0.15 in the frame hole | M1.6 × 6 ISO 7046 countersunk T5 from outside: Ø3.25 csk + Ø1.8 clearance, M1.6 nut + Ø4 washer on the frame back | M1.6 × 4 thread-forming pan T5 + Ø4 washer from the frame side into a blind Ø1.30 pilot, 0.45 skin left |
> | **SCR_C2** | (53.45, 58.27) | Ø4.2 | 0.33 flex, 0.83 foam, 0.21 frame | same; washer **Ø6** because the frame hole is Ø4.84 | same; washer Ø6 |
>
> In csk mode the heads are visible on the outer face between the C columns.
>
> **Clearance (default; pt in brackets where it differs).**
>
> | Check | SCR_C1 | SCR_C2 |
> |---|---|---|
> | Nearest plate opening | C4 3.54 (3.87) | W_TB window 3.54 (3.07) |
> | Flex light pad / LED | LED (53.3, 70.9) 2.69 | PAD_TB 1.26 |
> | Receptacle shells, in plan | C4 2.67 | C6 2.03 |
> | Flex neck | 34.9 | 23.0 |
> | Speaker | 20.3 | 19.0 |
> | J31 | 64.6 | 47.7 |
> | Coin cell | 57.1 | 71.5 |
> | CONN_C / J7 (B side) | 64.9 | 46.7 |
> | J8 (B side) | 56.5 | 38.8 |
>
> - Module paddles and JMs lie under the posts in plan, but they are ≤ 2.34 above the board. The fastener ends 13.73 (14.23) above the board, so there is no conflict.
> - **Needs action 1, module clamp plate C** (PA12 1.6, top 15.26 above the board, 0.57 below the frame back). Both centre fasteners hang into it:
>   - It needs a **Ø5.0 clearance hole at SCR_C1** and a **Ø7.0 hole at SCR_C2**.
>   - At SCR_C1, the C clamp-post M2 screw at (53.19, 70.80) leaves only ≈ 0.3 of web. Move the post (H21) to Y ≤ 69.8, or merge the hole into a slot.
> - **Needs action 2, main board H13.** The frame-centre standoff (53.38, 58.38) sits directly under SCR_C2.
>   - Either drop H13 and use the nut,
>   - or make H13 an M1.6 standoff reaching the frame back (15.8) and run SCR_C2 (csk, M1.6 × 6–8) plate → frame → H13, without the nut. That is not possible in pt mode.
>   - The board is unchanged pending M-IOC4.
> - Existing item noticed: the M2 clamp-post screw heads on the clamp-plate top (15.26) have only 0.57 under the frame centre bar. They need countersinking in the clamp plate or frame clearance.
> - The corner screws were re-checked against the same list:
>   - SCR_B−: the washer/nut footprint overlaps the J31 ZIF in plan by 0.34, but sits 12.7 above the board. J28 is 1.0 away in plan. Check the flex tail route from the neck to J31 clears the SCR_B− nut by ≥ 2.
>   - SCR_T−: 0.61 in plan to the BT1 holder, 4.0 to the cell, 12.7 above the board.
>   - Speaker ≥ 19.8; flex neck ≥ 11.6.
>
> **Wall:**
> - General 1.372–1.423 (exact 1.400).
> - Seats unchanged.
> - Bosses and posts 0.37 (csk lip) to 3.37.
> - All 4 variants are single solids; z extent −4.71..0.
>
> **Centre-screw measurements (M-IOC*)**
> - **M-IOC1:** centre hole positions on the plate from the plate edges and the AC opening (calipers), and on the frame. Diameters: frame C1 Ø3.17 and C2 Ø4.84 (trace), flex Ø3.30 / Ø5.08.
> - **M-IOC2:** the stock post. Is there a post on the inner face, and what are its OD and length (inner face → frame front)? Foam thickness, free and compressed.
> - **M-IOC3:** the stock screw. Which side it is driven from, head type, Ø and height, drive, thread (M1.4 / M1.6 / M2), length. What it threads into: a nut, a clinch nut, a tapped frame, or the plastic post.
> - **M-IOC4:** is the frame also screwed to the board at C2 (decides H13)? Frame thickness at the centre bar, and frame-back height above the board (M-IOF2).
> - **M-IOC5:** is there a third screw at K11, between the audio jacks? Are the centre screws visible from outside with the case on?

> **Rev 2026-10-02 ≈ 16:10 ET: corner screws replace the glue (Aidan's suggestion, 15:55 ET).**
>
> *Evidence (`screw_candidates.py` → `io_plate_v2_A0_screw_candidates.png`).* Positions are back-view mm, read with the outer-face mapping of scan 83f0b85e.
>
> | # | Scan feature | Position (X, Y) | Size | Confidence | Interpretation / what it fastens to |
> |---|---|---|---|---|---|
> | K1 | sharp ring, image top-left | (74.77, 150.08) | dark core Ø1.0–1.3, ring Ø2.3–2.8 | high that it is a fixing point; X ±0.5, Y ±0.3 | stock plate→metal I/O frame fixing at frame hole CORNER (Ø3.16–3.50) |
> | K2 | sharp ring, image top-right | (29.84, 149.82) | same, ring partly in the corner shadow | high / ±0.5 | same |
> | K3 | sharp ring, image bottom-left | (74.60, 15.05) | same | high / ±0.5 | same |
> | K4 | ring, image bottom-right, half off the scan edge | (29.54, 13.93) | not measurable | medium / ±0.8 | same (inferred by symmetry) |
> | K5 | dark round hole at the +X edge, glue residue | (79.52, 140.89) | Ø≈2.4 | low | clip / latch window, not a screw |
> | K6–K8 | C-shaped hook marks | (30.61, 140.70), (76.61, 23.24), (28.96, 21.08) | 3–4 mm arcs | medium | stock clip points (CLIPS_L), not screws |
> | K9 | soft ring, centre column | (53.4, 75.4) | Ø≈2.5 | medium | frame HOLE_C1 (Ø3.2) locating hole, not a plate screw |
> | K10 | soft dark ring, centre column | (53.4, 58.4) | Ø≈5 | medium | frame centre screw HOLE_C2 (Ø4.85), which goes **frame → board standoff H13**. The plate does not reach it, so it is unchanged. |
>
> **What the four rings are.** K1–K4 form a 44.9–45.2 × 135.3–135.9 rectangle. That matches the frame-trace corner holes (44.2 × 135.3, Ø3.16 / 3.39 / 3.30 / 3.50).
> - The core (Ø1.0–1.3) fits either an M1.4/M1.6 screw recess (T4/T5 Torx) or a Ø1.1–1.3 threaded or pilot hole.
> - The ring (Ø2.3–2.8) fits an M1.4 head (dk 2.6–2.8) or an M1.6 countersunk head (dk 3.0).
> - The scan cannot tell a screw head from a brass insert or a hollow heat stake, so the fastener type has **low** confidence.
> - **Design choice: M1.6**, the middle of the M1.4–M2 range. It is a 3.0 head in a Ø3.2–3.5 frame hole.
>
> **Design (`FIX = "screws"`, `SCREWS`, `SCREW_MODE` in `build_plate.py`).** There are 4 screws, symmetric about the plate centre line, at a 45.1 × 135.25 pitch:
> - SCR_T− (30.64, 149.95)
> - SCR_T+ (75.74, 149.95)
> - SCR_B− (30.64, 14.70)
> - SCR_B+ (75.74, 14.70)
>
> Why symmetric: a symmetric pattern lands in the same place whichever face the scan shows, so the open inner/outer-face question does not move it. The scan rings are symmetric to within about 0.5 mm. The axes are radial, ±11.7°.
> - **Default `csk`:**
>   - Screw: M1.6 × 5 ISO 7046 / DIN 965 countersunk T5, driven from the outer face.
>   - Plate: 90° countersink Ø3.25, so the head sits 0.12 below the face; Ø1.80 clearance hole.
>   - Spigot: Ø2.8 × 0.8 on the inner face, locating in the frame corner hole. It is shorter than the 1.0 frame, so the washer bears on the frame.
>   - Frame back: DIN 125 washer Ø4 × 0.3 + M1.6 nut, or the stock clinch nut if the frame has one.
>   - Local wall 2.2; the lowest fastener point is z −6.71, which leaves 12.7 to the board top.
> - **Variant `--screw pt --tag _screwpt`:**
>   - Screw: M1.6 × 3 thread-forming-for-plastics pan/wafer T5, driven from the frame side.
>   - Plate: blind Ø1.30 pilot with 0.45 skin left, so the outer face is unbroken; same spigot.
>   - Engagement is ≈ 1.75, which is short. Use this variant only for light clamping.
> - **Glue band kept as a fallback:** DXF layer `GLUE_LANDS_OPTIONAL`, one land of 963 mm², now also 0.6 clear of the screw spigots.
>   - New DXF layers: `SCREWS` (countersink, clearance or pilot) and `SCREW_BOSSES` (spigots).
>   - New features-JSON entries: `fixing.screws` (per-screw checks) and `kind = "BOSS"`.
>
> **Clearance (all four screws OK):**
>
> | Check | Clearance |
> |---|---|
> | Outline edge, outer face | ≥ 1.29 (csk) |
> | Outline edge, inner face | ≥ 1.52 |
> | Flex outline (bottom pair) | 3.63 / 4.17 |
> | Flex outline (top pair) | > 30 |
> | Flex neck | ≥ 11.6 |
> | Nearest opening (AC, AUD_H, W_AUD_O) | ≥ 8.4 |
> | Port modules (A2 / A4 at the bottom) | ≥ 9.1 |
> | Fastener stack to board top | 12.7 vertical |
>
> Nearest F-side board parts: BT1 coin holder 2.6 in XY (SCR_T−), J31 flex ZIF 1.7 in XY (SCR_B−), L41 4.2 (SCR_T+). All are well below the nut, which sits 12.7 above the board top.
>
> **Wall:**
> - Outside the bosses: 1.372–1.423, which is STL faceting; exact 1.400.
> - Seats unchanged: 1.09–1.42 default, 0.61–1.75 tilt.
> - Bosses (allowed local exception): 0.37 at the countersink lip up to 2.2 at the spigot.
>
> **Variants rebuilt:** `io_plate_v2_A0`, `_tilt12p5`, `_eth2blank`, `_screwpt` (STEP + STL), with thickness PNGs and iso renders for each.
>
> **Disagreement to resolve.** The 100 dpi frame trace, mirrored as used, puts its corner holes 0.6–2.8 mm from the design screws: X 33.4 / 77.6 at the top, 30.3 / 74.5 at the bottom. It is a 1.3° parallelogram, which is probably scan skew.
>
> **Measurements (before printing):**
> - **M-IOS1:** frame corner-hole centres from the frame edges, and the pitch (X and Y), by caliper. Also the hole Ø, and whether the holes are plain, tapped, or carry clinch nuts or inserts.
> - **M-IOS2:** gap from the plate inner face to the frame front face at the corners (set `CORNER_GAP`), and the frame thickness (M-IOF2).
> - **M-IOS3:** the stock fastener: head type (pan / countersunk / wafer), head Ø and height, drive, thread Ø and pitch (M1.4 × 0.3 / M1.6 × 0.35 / M2 × 0.4), length, and which side it is driven from. Or it may be a heat stake or insert.
> - **M-IOS4:** the plate corner features measured on the part. Ring and core Ø, centres from the plate edges, and whether the hole is through or blind. Is it visible on the outer face with the case on?
> - **M-IOS5:** which face the scan 83f0b85e shows (open). Weak hint: the corner rings are sharp while the centre features are soft, which on a flatbed would favour the concave inner face being on the glass. The translucent light guides blur anyway.

> **Rev 2026-10-02 ≈ 14:40 ET (Aidan's plate corrections, 13:37 ET):**
> - **HDMI and power button are back in the stock positions.** In the back view (design frame), HDMI is at **+X (63.86, 107.07)** and the button at **−X (43.02, 108.11)**.
>   - Root cause: the 821-2222-A flex trace was digitised from its board-facing side, so it was mirrored. `mirror_flex_trace.py` mirrors it about **X_M = 53.408** (least-squares over the port cut-outs; ports move ≤ 0.064). The original is kept as `flex_821-2222_trace_asscanned.json`.
>   - The frame features (`io_frame.json`) were registered to the same grid. They are mirrored on load in `build_plate.py` and `section_plot.py`.
>   - The stock cover openings were mirrored the same way, so the **audio holes move** to (42.17, 19.42) and (63.41, 19.10).
>   - **AC** = (53.30, 130.15), taken from the new scan.
> - **Glued, not clipped.**
>   - `GLUED = True`, so `CLIPS = []`. The 3.0 × 1.2 rim, the Ø2.4 frame/ear pins, the LED/button-carrier pockets, the frame-screw relief and the 0.2 flex pocket are all removed.
>   - The flex is PSA-bonded flat on the inner face.
>   - **Glue lands:** a perimeter band from 0.4 to 3.4 mm in from the edge, kept 0.6 clear of the flex, its neck and every opening. It is one continuous land of 992 mm². It is flat inner face with **no added material**, drawn on the DXF layer `GLUE_LANDS` and in the PNGs.
>   - Land width (−X/+X): 1.9–3.0 mm along the sides and 4.5 at the ends. The −X side is interrupted at Y 28–48 by the flex neck.
> - **1.4 everywhere, edges included.** `SKIN = 1.4`, `RIM_H = RIM_W = 0`.
>   - Check (`check_thickness.py`, STL ray-cast along the skin normal at 0.5 mm pitch over 18,661 points): 1.372–1.423. The ±0.03 is STL faceting.
>   - The exact B-rep probe gives **1.400 normal** at the crown, at the long edges (27.35 / 79.05) and at the ends (Y −4.45 / 158.6).
>   - The only departures are the port-attachment exception, the flat plug seats under USB-C/USB-A/HDMI:
>     - default variant: 1.09–1.40;
>     - `_tilt12p5`: 0.61–1.75 (wall ≥ 0.6).
>   - The Z extent is 4.51 (curvature + 1.4), so there is no rim or edge lip.
> - **Scan check** (`scan_overlay.py` → `io_plate_v2_A0_scan_overlay.png`):
>   - Order from the top matches: AC → HDMI slot + round button → ETH pair → 3 USB-C rows → 2 USB-A rows → audio holes → audio light windows.
>   - Outline 163.0 × 52.0 matches the design's 163.1 × 51.9; the curved +X edge is lifted and shadowed.
>   - Scan positions: button blob (42.49, 107.06); HDMI (63.75, 106.87); audio (42.18, 19.38) and (63.41, 19.31).
> - **Variants:** `io_plate_v2_A0.{step,stl}`, `_tilt12p5`, `_eth2blank`.
> - **Previews:** `_outer.png`, `_iso_inner.png`, `_section.png` (4 rows, now including the button/HDMI row), `_thickness.png`, `_scan_overlay.png`, `_preview.png`.
> - **Render scripts:** `render_plate.py` (shaded STL), `check_thickness.py`.
> - **Open (inside-face scan pending):** LED / button-carrier side of the flex, glue footprint on the stock frame, frame-screw head height (M-IOF2) and the AUD_H jack-nose margin (0.04 at an assumed Ø6.0).

> **Rev 2026-10-02 ≈ 12:45 ET (D-IO16 swappable flex port modules):**
> - **Default axes:** port axes are **normal to the plate** (`TILT_OVERRIDE_DEG = None`: C −5.27 / +5.47°, A −5.25 / +5.51°, HDMI −5.33°). Plugs seat fully: overmold stand-off 0.0 with the seats, 0.03–0.04 without. Mouths are 18.40–18.59 above the board.
> - **Stock-tilt variant:** `--tilt 12.5 --tag _tilt12p5` writes `io_plate_v2_A0_tilt12p5.{step,stl}` and `_features.json` (no DXF / PNG). Its stand-off with the seats is C 0.68–0.72, A 1.14–1.21, HDMI 1.43; without them C 1.27–1.31, A 1.73–1.80, HDMI 2.02. Its frame slot is ≥ 0.19 (HDMI).
> - **Settings:** `AXIS_SHIFT_OUT = {}`. `RISER_T` = 1.16 is now the module stack under the connector seat (FPC 0.11 + PSA 0.05 + FR4 stiffener 1.0). USB-C is the HYCW417 (H 10.0, all SMD).
> - **Section plot:** `section_plot.py` now draws the modules: stiffener, FPC, SUS sleeve + collar, clamp plate (top = frame back − 0.3), cradle, C-fold and the DF40 pair. Module geometry is in `/workspace/kicad/macpro62-io-modules/modules.json`.
> - **Superseded text:** the riser text below is superseded.

> **Rev 2026-10-02 ≈ 12:00 ET (measured stock tilt, M-IOT2: 12.5° outward, mirrored):**
> - `TILT_OVERRIDE_DEG = 12.5` (None = radial 5.3–5.5°). The ports are **7.0–7.25° off the plate normal** at R 110, so the axis/mouth code no longer assumes radial axes: exact axis–surface intersection, mouth with no point proud (`MOUTH_CLR` 0.05), per-layer clearance of the tilted shell (flex, foam +0.3, frame slot) in `features.json → tilt.check`.
> - `AXIS_BALANCE` (HDMI −0.22 mm to clear the frame slot) and `AXIS_SHIFT_OUT = {"USBA": 0.35}` (USB-A riser edge clearance).
> - New `TILT_SEAT`: flat plug seats perpendicular to each axis on the OUTER face (overmold + 2 × 0.25, floor keeps ≥ 0.6 skin). Overmold stand-off USB-C 1.3 → 0.7, USB-A 1.7 → 1.1–1.2, HDMI 2.0 → 1.4 mm (open risk, M-IOT3 / M-IOC2).
> - Mouth centres 17.46–18.03 above the board (were 18.41–18.59). Flex margins ≥ 0.17 (HDMI Y, unchanged), X ≥ 0.19; frame slots ≥ 0.19. Inner face unchanged (smooth, flex flat).
> - Previews: `io_plate_v2_A0_section.png` (seat floors in violet), `io_plate_v2_A0_outer.png` (seats), `io_plate_v2_A0_preview.png` (flex check + outer + section).

> **Rev 2026-10-02 ≈ 11:30 ET (stock cover phone scan check, no geometry change):**
> - Scan (`../io_cover_scan/`, Gaussian-splat PLY) registered to the plate at **0.49 mm RMS** over 13 openings after a 0.931 rescale. Outline width ≈ 52.4 vs 51.9 (blur ≈ 0.5), centre and corners agree: **outline kept**.
> - Inner radius from the scan ≈ 101.7 (bootstrap 99.7–103.7, band spread 77–123) vs **109.97 from D0**: consistent, D0 kept. New switch `R_INNER_OVERRIDE = None` (set 101.7 to use the scan fit); `params.cover_scan` in the features JSON records the check.
> - Clips, ribs, bosses, pins, glue pocket and wall thickness are below the scan's resolution: unchanged. STEP/STL/DXF/PNGs regenerated (identical geometry).

> **Rev 2026-10-02 ≈ 10:50 ET:**
> - Plate radius re-derived from D0 (18.0 crown / 16.5 at the outer edge of the outermost port columns, |u| 18.1): **R 111.17 outer**.
> - USB-C / USB-A / HDMI openings are **straight through-holes along the tilted port axes** (±5.25–5.51°, D-IO14 column risers). The USB-C spot-faces are removed.
> - The smooth inner face and the flex fit are unchanged. Shell-in-cut-out margins: USB-C 0.45, USB-A 0.34, HDMI 0.17.
> - Mouth centres sit 18.41–18.59 above the main board.
> - Section: `io_plate_v2_A0_section.png`. Riser geometry: `/workspace/kicad/macpro62-io-risers/risers.json`.
> - Text below that mentions spot-faces, R 82 or straight port risers is superseded.

# MP62 I/O plate v2 rev A0 (new plastic plate; stock metal I/O frame and stock 821-2222-A flex kept)

Generated by `build_plate.py` (cadquery 2.8 + ezdxf): `/workspace/cadenv/bin/python build_plate.py [--eth2 open|blank]`, then `section_plot.py`.
The flex trace comes from `bracket/io_stock_photos/scan/bake_scan.py`.

**Rev 2026-10-02 ≈ 10:07 ET (flatbed scan of the 821-2222-A flex + measured D0):**
- No lands, bosses or ramps. The inner face is one smooth cylinder, so the stock flex lies flat in its 0.2 glue pocket.
- The port grid is the set of flex cut-out centres.
- The curvature comes from D0 (18.0 at the crown, 16.5 at |u| = 15.5): outer R 82.03.
- Connector heights and stack-up are in `io_plate_v2_A0_features.json` → `stack`. See IOB plan §4.7.1–4.7.4.

Coordinates are in the stock back-view frame: X to the right seen from behind, Y up toward the MEG/base end (audio at the bottom), Z = 0 at the outer crown, −Z into the machine. The board top is at z −19.2.

| File | Content |
|---|---|
| `io_plate_v2_A0.step` / `.stl` | Rev A0 default, ETH2 open (2 × RJ45) |
| `io_plate_v2_A0_eth2blank.step` / `.stl` | ETH2 blank (0.6 cosmetic recess), `--eth2 blank` |
| `io_plate_v2_A0_openings_backview.dxf` / `_frontview.dxf` | Outline, openings, windows, spot-faces, clips and pins. The front view uses the KiCad x frame (x = 40 + 101.0 − Xb). |
| `io_plate_v2_A0_features.json` | Parameters (incl. D0), parts, `stack` (required heights, plug recess, risers), `flex_check`, `led_check`, features |
| `io_plate_v2_A0_preview.png` | Outer face plus inner isometric |
| `io_plate_v2_A0_section.png` | Sections through the USB-C, USB-A and RJ45 rows: plate, flex, foam, frame, board top, connectors on risers |
| `io_plate_v2_A0_outer.png`, `io_plate_v2_A0_iso_inner.png` | Extra previews |
| `io_plate_v2_A0_button_closeup.png` (`button_closeup.py`) | Power-button area (rev 2026-10-04 ≈ 15:30 ET): plan with the scan underlay, flex trace, raised collar + key tab, ear bosses with the M1.4 head circles, frame opening and HDMI clamp post; sections A-A (both ear bosses) and B-B (along X) with the assumed button-island line; 3D inner face |
| `flex_821-2222_trace.dxf` / `.json` | Scan-based, idealised trace of the plate-facing side: outline, cut-outs, holes, pads, silver frames, 19 LEDs, button, tail + contacts, `IGNORED_BLACK_TAB`, reference layers. ±0.15; VERIFY by caliper |
| `flex_821-2222_scan_vs_photo_deltas.md` | Deltas against the 09:06 photo trace |
| `flex_821-2222_check.png` | Flex against openings, shells, frame slots, LEDs, pins and clips, with margins and required heights |
| `io_flex_foam_insulator_A0.dxf` | Foam / Formex die-cut: flex outline minus cut-outs + 0.3, holes + 0.5, button ring + 0.5, ear holes Ø3.1 for the M1.4 heads (boss mode, 15:30 ET; Ø2.2 with `--ear-posts`) |
| `io_plate_v2_A0_scan_compare.png` (`scan_prints/overlay_model_on_scan.py`) | Current model (new outline solid, old dashed; openings, Ø5.3 audio, collar, bosses, corner screws + older-build markers) overlaid on Aidan's 2026-10-04 scan of the 3 prints and the stock plate, each registered on its openings; stock zooms of the corners, button and audio |
| `scan_prints/` | Scan (`prints_vs_stock_scan.jpg`, 200 dpi), measurement scripts (`measure_scan.py`, `warp.py`, `blobs2.py`, `corners_fit.py`, `width2.py`, `overlay_model_on_scan.py`) and results (`registration.json`, `scan_compare.json`, `outline_fit.json`, `corner_radius_fit.json`, `blobs_openings.json`) |

## Geometry (mm)

- **Outline:** 52.7 × 163.1, R 12.8 at (53.19, 77.07) (rev 15:30 ET; was 51.9 × 163.1 R 11.5).
- **Body:** constant 1.2 wall. Outer R 82.03, inner face concentric. Rim 1.2 × 3.0, notched at X 76.0–81.5 / Y 27.7–47.6 for the flex neck.
- **Openings:** straight through, no lands.
  - USB-C 9.6 × 4.0 R 1.8 at X 43.09 / 63.69, Y 75.76 / 65.84 / 55.97.
  - USB-A 14.0 × 6.0 at X 43.12 / 63.76, Y 42.64 / 32.54.
  - ETH1 13.0 × 10.4 at (63.67, 91.60); ETH2 13.0 × 10.7 at (43.15, 91.41).
  - HDMI 15.6 × 5.7 at (42.96, 107.07). AC stock window.
  - Audio Ø5.3 (rev 15:30 ET; was Ø4.8) at the stock positions. Button Ø12.4 at (63.79, 108.11).
- **Flex seat:**
  - Glue pocket 0.2 deep (outline + 0.2).
  - 19 LED pockets and a Ø16.17 button-carrier pocket, 0.70 above the flex face (wall 0.35; `LED_H`, `BTN_CARRIER_H` TO MEASURE).
  - Light windows on the scanned pads.
  - Locating pins Ø2.4 × 2.5 at (52.93, 75.41) / (54.49, 19.23); ear pins Ø1.4 × 0.8.
- **Outer spot-faces** at the two USB-C columns: 12.8 × 26.8, floor z −0.68 / −0.70, wall ≥ 0.6.
- **Clips:** 7. The mirrored clip at (76.78, 30.3) is dropped because of the flex neck. The stock clip points stay.
- **Required board-top-to-mouth heights:**
  - USB-C 17.90 (H) / 17.82 (O).
  - USB-A 17.49 / 17.38.
  - HDMI 17.24 (the shell must be ≤ 15.4 × 5.6 to pass the flex).
  - RJ45 face ≤ 13.6 / 13.7.
- **Plug recess:** USB-C 0.62–0.67, USB-A 1.69–1.78, HDMI 1.96.
- **Rebuild:** if D0, the wall, foam, frame or LED heights change, edit the parameters at the top of `build_plate.py` and rebuild.
- `--flex none` (collars, light pipes) is retired.

## Process, material, tolerances (ordering at JLC3DP or PCBWay)

| Process | Use | Notes |
|---|---|---|
| **MJF PA12, dyed black** | **Recommended (rev A)** | Tough, clips survive, no supports. About $10–20 each. |
| SLA black resin (tough/ABS-like) | Cosmetic second print | Best surface. Brittle clips: use L 7.0, hook 0.4. Supports go on the inner face. |
| CNC (ABS, PC, POM) | Final batch only | ±0.05, about $80–200 (curved face + pockets + clips). |
| Clear SLA, polished | Power-button cap | Light passes through to D20. Cap CAD is TODO (Ø12.0 × 3 on a Ø6 stem). |

**Design values:**
- Skin 1.2 (1.0 under the glue pocket); rim 1.2 × 3.0; land backing 1.0 (≥ 0.8 at the ramps); pins Ø2.7; clip tab 1.2.
- MJF minimum wall is about 0.8 (1.0 recommended); SLA about 0.6–0.8 [vendor rules, check on the order page].
- Tolerance about ±0.2–0.3 mm or ±0.3 % (±0.5 over the 163 mm length). Openings carry ≥ 0.3 per side; USB-C is 9.6 × 4.0 R1.8 around an 8.94 × 3.26 shell.
- MJF holes print 0.1–0.2 small: light-pipe bores are Ø2.2 for Ø2.0 PMMA rods (ream if tight).
- **Snap clips:** 1.2 t × 5.0 w × 6.0 L, hook 0.5, so bending strain ≈ 1.5·t·y/L² = 2.5 % (PA12 OK). Too stiff: file the hook. Loose: hook 0.6.
- Plate-to-frame clearance is 0.2–0.3 per side.

**Order:**
- Upload `io_plate_v2_A0.stl` (or `.step`): MJF PA12, dyed black, qty 2, standard bead-blast finish, no supports.
- Order `io_plate_v2_A0.*` (ETH2 open). The `_eth2blank` file is only for a single-Ethernet build.
- **Not ordered.** Measure M-IOT2 (curvature) and M-IOF2 (D0) first.
