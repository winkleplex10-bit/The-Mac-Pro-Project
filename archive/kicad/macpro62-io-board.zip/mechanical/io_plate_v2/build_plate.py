#!/usr/bin/env python3
"""MP62 I/O plate v2 rev A0 (new plastic plate; stock metal I/O frame and the stock 821-2222-A I/O-wall flex are reused). cadquery 2.8 + ezdxf.
Frame: stock BACK-VIEW frame of the I/O board (mm): origin at the board's bottom-left virtual corner, X to the right as seen from behind
the machine, Y up toward the MEG-array / base end. Z = 0 is the crown of the plate OUTER (visible) face, -Z goes into the machine.
Usage: python build_plate.py [--eth2 open|blank]
Rev 2026-10-02 ~10:07 ET (Aidan flatbed scan of the 821-2222-A flex + measured D0):
  * port grid = centres of the stock flex cut-outs (scan trace flex_821-2222_trace.json); USB-C columns X 43.09 / 63.69;
  * NO lands, NO bosses: every opening goes straight through the curved 1.2 skin, the inner face is one smooth cylinder so the stock
    flex lies flat (bosses cannot fit inside the flex cut-outs: <= 0.4 mm/side); the flex sits in a 0.2 glue pocket;
  * curvature from D0 (board top -> cover inner face): 18.0 at the crown, 16.5 at |u| = D0_EDGE_U -> inner R ~80.8, outer R ~82.0;
  * clearance pockets on the inner face for the flex's plate-side LEDs and the button carrier, ear pins, Ø2.4 locating pins;
  * shallow outer spot-faces at the USB-C columns (plug overmold relief, >= 0.6 wall kept);
  * connector mouth heights / stack-up reported in io_plate_v2_A0_features.json ("stack")."""
import json, math, os, sys
import cadquery as cq
import ezdxf
from matplotlib.path import Path as MPath
HERE = os.path.dirname(os.path.abspath(__file__))
ETH2 = "open"    # rev A0 default (D-IO2: 2 x i226-V); "--eth2 blank" builds the single-Ethernet variant
if "--eth2" in sys.argv: ETH2 = sys.argv[sys.argv.index("--eth2") + 1]
TAG = sys.argv[sys.argv.index("--tag") + 1] if "--tag" in sys.argv else ""     # variant builds (e.g. --tilt 12.5 --tag _tilt12p5): own STEP/STL/features JSON, no DXF/PNG
FJ = json.load(open(os.path.join(HERE, "flex_821-2222_trace.json")))
CUT = {c["id"]: c for c in FJ["cutouts"]}
PADS = {p["id"]: p for p in FJ["light_pads"]}
BTN = FJ["button"]

# ---------------- stack-up (z, mm; 0 = crown of the outer face) ----------------
SKIN = 1.4                                  # Aidan 2026-10-02 13:37 ET: the WHOLE faceplate is 1.4 thick, edges included; only the port attachments
                                            # (plug seats / spot-faces) differ. No rim, no clips, no pockets, no pins (rev ~14:20 ET)
D0_CROWN, D0_EDGE = 18.0, 16.5            # Aidan 2026-10-02: board top -> cover inner face, crown / outermost port edge
D0_EDGE_SIDE = "mean"                        # Aidan 10:21 ET: 16.5 read at the outer edge of the outermost port columns -> "mean" | "H" | "O" | a number (|u| in mm)
_ce = [c for c in json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "flex_821-2222_trace.json")))["cutouts"] if "w" in c]
_uH = 53.19 - min(c["cx"] - c["w"] / 2 for c in _ce if c["cx"] < 53.19)   # H side: HDMI outer edge (X 34.89)
_uO = max(c["cx"] + c["w"] / 2 for c in _ce if c["cx"] > 53.19) - 53.19   # O side: USB-A outer edge (X 71.09)
D0_EDGE_U = {"mean": (_uH + _uO) / 2, "H": _uH, "O": _uO}.get(D0_EDGE_SIDE, D0_EDGE_SIDE) if isinstance(D0_EDGE_SIDE, str) else D0_EDGE_SIDE
_s = D0_CROWN - D0_EDGE
R_INNER = (D0_EDGE_U ** 2 + _s ** 2) / (2 * _s)     # 109.97 from D0 (rev 10:21 ET)
# Stock-cover phone scan (2026-10-02 11:07, ../io_cover_scan/io_cover_scan_check.json): inner-face fit R 101.7 (bootstrap 99.7-103.7,
# Y-bands 94-123, half-width 16-24 mm -> 77-102): consistent with the D0 value, rules out the old 82, but not tighter than D0 -> kept.
R_INNER_OVERRIDE = None                      # e.g. 101.7 to use the scan fit instead of D0 (one-line switch; risers.json/tilt follow)
if R_INNER_OVERRIDE: R_INNER = R_INNER_OVERRIDE
CASE_R = R_INNER + SKIN                      # 111.17 outer
Z_BOARD = -SKIN - D0_CROWN                   # stock board top at -19.2 (our board top assumed at the same plane: MEASURE M-IOS2)
FLEX_T, PSA_T = 0.12, 0.05                   # flex + its PSA [Estimate, MEASURE]
FOAM_T = 1.0                                 # stock foam behind the flex (board side) [Aidan ~1, MEASURE]
FRAME_T = 1.0                                # metal I/O frame thickness, assumed concentric with the plate [MEASURE M-IOF2]
FLEX_POCKET = 0.0                            # rev ~14:20 ET: no glue pocket (1.4 everywhere); the flex is PSA-bonded flat on the inner face (was 0.20)
FLEX_CLR = 0.20                              # pocket outline = flex outline + this (also locates the flex: +-0.2)
LED_H, LED_CLR = 0.60, 0.25                  # plate-side LED chip height above the flex face [MEASURE], pocket clearance per side
BTN_CARRIER_H = 0.60                         # button carrier ring height above the flex face, plate side [MEASURE]
POCKET_GAP = 0.10                            # air gap above LEDs / carrier
MIN_WALL = 0.6                               # outer spot-faces keep at least this wall

# ---------------- outline, ports ----------------
# rev 2026-10-04 ~15:30 ET (Aidan's 200 dpi flatbed scan of 3 prints + the stock part, scan_prints/): the stock outline is 0.75 +- 0.3 WIDER than the
# prints (sharp edge to shadow-free edge, sub-scan axis = no perspective) and its corners are R 12.5-12.8 (prints read 0.3 below their model R 11.5),
# so W 51.9 -> 52.7 (symmetric about the plate centre X; the scan hints at up to +0.4 more on +X, low confidence) and R 11.5 -> 12.8.
# Length / Y ends match the stock within 0.2 (opening-registered) -> unchanged.
PL_W0, PL_R0 = 51.9, 11.5                     # pre-15:30 outline (fit of the stock cover scan 83f0b85e)
SHIELD_W_ADD = 0.8; PL_R_NEW = 12.8
PL_C = (53.19, 77.07); PL_W, PL_H, PL_R = round(PL_W0 + SHIELD_W_ADD, 3), 163.1, PL_R_NEW      # outline
RIM_H = 0.0; RIM_W = 0.0                     # rev ~14:20 ET: rim removed (was 3.0 x 1.2) - the edge is the 1.4 wall itself
GLUED = True                                 # Aidan 13:37 ET: the plate is GLUED into the frame, not clipped -> no clips; glue lands instead
# ---- screw fixing (rev 2026-10-02 ~16:05 ET, Aidan: replace the glue with screws at the stock corner points) ----
FIX = "screws"                               # "screws" (default) | "glue" (fallback: the GLUE_LANDS_OPTIONAL DXF layer / bead plan stays valid either way)
SCREW_MODE = sys.argv[sys.argv.index("--screw") + 1] if "--screw" in sys.argv else "csk"
#   "csk": M1.6 x 5 countersunk Torx (ISO 7046 / DIN 965, dk 3.0) from the OUTER face, 90 deg countersink, Ø1.8 clearance, spigot into the
#          frame corner hole, M1.6 washer Ø4.0 x 0.3 + M1.6 nut (3.2 AF x 1.3) on the frame back (or a stock clinch nut if the frame has one, M-IOS3)
#   "pt" : M1.6 x 3 thread-forming-for-plastics pan/wafer Torx (Ø4 head or + washer) from the FRAME side into a blind Ø1.30 pilot; outer face unbroken
# stock corner points from the 300 dpi outer-face flatbed scan 83f0b85e (4 rings: dark core Ø1.0-1.3, ring Ø2.3-2.8): pitch 45.1 x 135.3,
# centred on the plate X (scan symmetric to +-0.5; a symmetric pattern is the same on either face, so the inner/outer-face question does not move it)
# rev 2026-10-04 ~10:30 ET (Aidan, test print): all 4 corner mounts moved +1.0 in Y = toward the plate's TOP edge (away from the audio jacks at Y ~19);
# scan read was (149.95, 14.70)
# rev 2026-10-04 ~13:05 ET (Aidan): that move was the WRONG way - corner mounts go 1.0 from the ORIGINAL positions in -Y (toward the audio-jack end),
# i.e. 2.0 from the 10:30 positions: SCR_T-/+ (30.64/75.74, 148.95), SCR_B-/+ (30.64/75.74, 13.70)
SCREW_SHIFT_Y = -1.0
SCREW_PITCH_X, SCREW_Y = 45.1, (149.95 + SCREW_SHIFT_Y, 14.70 + SCREW_SHIFT_Y)
SCREWS = [("SCR_T-", PL_C[0] - SCREW_PITCH_X / 2, SCREW_Y[0]), ("SCR_T+", PL_C[0] + SCREW_PITCH_X / 2, SCREW_Y[0]),
          ("SCR_B-", PL_C[0] - SCREW_PITCH_X / 2, SCREW_Y[1]), ("SCR_B+", PL_C[0] + SCREW_PITCH_X / 2, SCREW_Y[1])] if FIX == "screws" else []
SCREW_D = 1.6; SCREW_CLR_D = 1.80; SCREW_PILOT_D = 1.30; SCREW_CSK_D = 3.25   # csk Ø at the surface (90 deg): dk 3.0 head sits 0.12 below the outer face
SCREW_PT_SKIN = 0.45                         # "pt": material left under the blind pilot on the outer face
SPIGOT_OD = 2.8; SPIGOT_L = 0.8              # locating spigot into the frame corner hole (scan Ø3.16-3.50) - shorter than FRAME_T so the washer/head bears on the frame
CORNER_GAP = 0.0                             # plate inner face -> frame front face at the corners (glue band lands on the frame lip: assumed 0, MEASURE M-IOS2)
BASE_OD = 4.6                                # boss base (only if CORNER_GAP > 0)
GLUE_EDGE, GLUE_KEEP, GLUE_BAND = 0.4, 0.6, 3.0              # glue land = inner-face band from GLUE_EDGE inside the outline to GLUE_KEEP outside the flex / openings
PLATE_SIDE_POCKETS = False                   # LED / button-carrier pockets: OFF - the mirrored flex trace puts the LEDs + carrier on the BOARD side (inside-face scan to confirm)
PINS_ON = False                              # Ø2.4 frame pins + ear pins: OFF (1.4 everywhere; glue-in, located by a port-plug jig)
SCREW_RELIEF_ON = False                      # frame centre-screw head relief: OFF (needs head <= flex + PSA + foam ~1.1 above the frame face, M-IOF2)
ETH2_BLANK_RECESS = False                    # blank ETH2 legend recess: OFF (would leave 0.8 wall)
XH, XO = CUT["C1"]["cx"], CUT["C4"]["cx"]                        # USB-C columns from the flex cut-outs (43.09 / 63.69)
OPEN = []   # (id, kind, cx, cy, w, h, r)   plate opening = straight through the skin
for i in range(3):
    for cid in ("C%d" % (i + 1), "C%d" % (i + 4)):
        OPEN.append((cid, "USBC", CUT[cid]["cx"], CUT[cid]["cy"], 9.6, 4.0, 1.8))
for a in ("A1", "A2", "A3", "A4"):
    OPEN.append((a, "USBA", CUT[a]["cx"], CUT[a]["cy"], 14.0, 6.0, 0.6))
OPEN.append(("ETH1", "RJ45", CUT["ETH1"]["cx"], CUT["ETH1"]["cy"], 13.0, 10.4, 0.5))
if ETH2 == "open": OPEN.append(("ETH2", "RJ45", CUT["ETH2"]["cx"], CUT["ETH2"]["cy"], 13.0, 10.7, 0.5))
OPEN.append(("HDMI", "HDMI", CUT["HDMI"]["cx"], CUT["HDMI"]["cy"], 15.6, 5.7, 1.0))
OPEN.append(("AC", "AC", 53.30, 130.15, 34.55, 24.65, 3.0))   # rev ~14:25 ET: centre from the outer-face flatbed scan 83f0b85e (was 52.08, 129.95 from the cover photo); size kept
# rev ~15:30 ET (Aidan): audio-jack holes +0.5 (prints too tight; the stock hole reads Ø4.8 +- 0.3 on the scan, blurred - no reason to deviate)
AUD_D = 5.3
ROUND = [("AUD_H", 42.17, 19.42, AUD_D), ("AUD_O", 63.41, 19.1, AUD_D), ("PWR_BTN", BTN["cx"], BTN["cy"], 12.4)]   # audio = stock cover-scan holes MIRRORED about X_M 53.408 (2026-10-02 outer-face scan: 42.18,19.38 / 63.41,19.31)
WINDOWS = [("W_HDMI", PADS["PAD_HDMI"]["cx"], PADS["PAD_HDMI"]["cy"], 7.0, 1.6, 0.6), ("W_ETH", PADS["PAD_ETH"]["cx"], PADS["PAD_ETH"]["cy"], 3.0, 5.0, 1.0),
           ("W_TB", PADS["PAD_TB"]["cx"], PADS["PAD_TB"]["cy"], 3.0, 5.0, 1.0), ("W_USB", PADS["PAD_USB"]["cx"], PADS["PAD_USB"]["cy"], 3.0, 6.0, 1.0),
           ("W_AUD_H", PADS["PAD_AUD_H"]["cx"], PADS["PAD_AUD_H"]["cy"], 4.0, 2.4, 0.8), ("W_AUD_O", PADS["PAD_AUD_O"]["cx"], PADS["PAD_AUD_O"]["cy"], 4.0, 2.4, 0.8)]
CLIPS_L = [(31.0, 140.0), (28.2, 90.0), (29.6, 30.3)]           # stock clip points (left), mirrored about the plate centre X
CLIP_B = [(44.1, 2.7)]
CLIPS = [(x, y, "x-") for x, y in CLIPS_L] + [(2 * PL_C[0] - x, y, "x+") for x, y in CLIPS_L] + \
        [(x, y, "y-") for x, y in CLIP_B] + [(2 * PL_C[0] - x, y, "y-") for x, y in CLIP_B]
CLIP_T, CLIP_W, CLIP_L, CLIP_HOOK = 1.2, 5.0, 6.0, 0.5
FRAME_SCREW = (53.436, 58.38); SCREW_POCKET_D, SCREW_POCKET_DEPTH = 6.0, 0.6   # screw mirrored about X 53.408 with the flex (was 53.38)
LOCATE_PINS = [("PIN_C1", 53.886, 75.41, 2.4), ("PIN_C3", 52.326, 19.23, 2.4)]   # rev ~14:20 ET mirrored with the flex trace about X 53.408 (were 52.93 / 54.49); PIN_LEN = 2.5    # frame holes (frame scan); pass the flex holes Ø3.3 / Ø5.67
EAR_PINS = [(h["id"], h["cx"], h["cy"], 1.4) for h in FJ["holes"] if h["id"].startswith("BTN_EAR")]; EAR_PIN_LEN = 0.8   # locate the button end of the flex
_nx = FJ["neck"]["x"]; _out = 1 if (_nx[0] + _nx[1]) / 2 > PL_C[0] else -1     # rev ~14:20 ET: neck side follows the (mirrored) trace -> now the -X edge
NECK = (_nx[0] - (0.15 if _out > 0 else 0.9), FJ["neck"]["y"][0] - 0.5, _nx[1] + (0.9 if _out > 0 else 0.15), FJ["neck"]["y"][1] + 0.5)   # where the flex neck leaves over the plate edge
# outer spot-faces (plug overmold relief) per USB-C column: (id, cx, cy, w, h, r); floor = flat, >= MIN_WALL everywhere
_cy = [CUT["C%d" % k]["cy"] for k in (1, 2, 3)]
RELIEF = []   # rev 10:30 ET: tilted ports, mouth tangent to the face -> no overmold spot-faces needed
TILT_KINDS = ("USBC", "USBA", "HDMI")        # these sit on tilted column risers, axis normal to the plate at the opening (D-IO14)
TILT_OVERRIDE_DEG = None                     # rev 12:35 ET (port modules, D-IO16): DEFAULT = axis normal to the plate at each opening (full plug seating).
                                             # Stock = 12.5 outward (M-IOT2, Aidan 11:47 ET): build with "--tilt 12.5 --tag _tilt12p5" for the comparison report.
                                             # None = surface normal from CASE_R (5.3-5.5 deg at R 110); any number forces |tilt| (sign = outward)
if "--tilt" in sys.argv: _tv = sys.argv[sys.argv.index("--tilt") + 1]; TILT_OVERRIDE_DEG = None if _tv == "normal" else float(_tv)
MOUTH_CLR = 0.05                             # no point of a tilted shell mouth closer than this to the outer surface (mouth never proud)
AXIS_SHIFT_OUT = {}                          # extra OUTBOARD axis shift at the flex plane (mm). Was {"USBA": 0.35} for the 12.5 deg column risers; port modules are separate -> none
AXIS_BALANCE = True                          # shift each tilted axis along X (at the flex plane) to maximise the smallest flex / foam / frame-slot margin
TILT_SEAT = True                             # flat plug seats on the OUTER face, perpendicular to the port axis (reduce the overmold stand-off of an off-normal port)
SEAT_CLR, SEAT_MIN_WALL = 0.25, 0.6          # seat = plug overmold + 2 x SEAT_CLR; the floor keeps >= SEAT_MIN_WALL of skin (inner face stays smooth for the flex)
RISER_T = {"USBC": 1.24, "USBA": 1.16, "HDMI": 1.24}   # D-IO16 port module stack below the connector seat = FPC + stiffener PSA 0.05 + FR4 1.0 (rev ~13:30 ET: MOD-C / MOD-H on the
                                             # JLC 2-layer 50 um PI core FPC 0.19 for 90/100 ohm on a solid GND; MOD-A on the 25 um core 0.11 for its tighter loop fold). Keys keep the "riser_*" names
CONN_H = {"USBC": 10.0, "USBA": 13.7, "HDMI": 10.5}   # catalogue heights of the riser connectors (mating face above the riser top)
LEGEND = [("blank ETH2 recess", CUT["ETH2"]["cx"], CUT["ETH2"]["cy"], 13.0, 10.7)] if ETH2 == "blank" else []
# connector envelopes: shell (passes plate + flex), overmold of the mating plug (spec max / typical)
SHELL = {"USBC": dict(shell=(8.94, 3.26), overmold=(12.35, 6.5)), "USBA": dict(shell=(13.3, 5.7), overmold=(16.0, 8.0)),
         "HDMI": dict(shell=(15.2, 5.5), overmold=(20.0, 10.5)), "RJ45": dict(body=(16.2, 17.0), plug=(11.7, 8.2))}
PARTS = {
    "USBC": dict(mpn="HOAUC HYCW417-USBC24-180B", lcsc="C5342202", h=10.0, note="USB 3.1 Type-C 24P vertical, ALL-SMD (signal + shell tabs) for FPC mounting, L 10.0 (VERIFY drawing: height / shell tabs); alt SHOU HAN TYPE-C 24PLT-H10.5 C3151750 (THT shell legs) with CONN_H 10.5"),
    "USBA": dict(mpn="Hong Cheng HC-USB3.0-L137-WJ", lcsc="C7501870", h=13.7, note="USB 3.0 Type-A 9P vertical, H 13.7, shell 13.30 x 5.70 SPCC Ni (solderable sleeve), THT 9 x D0.70 + 2 shell legs D2.30 at 13.15 (HC drawing, rev A); 35 N mating max, 1500 cycles. Through the FPC + drilled FR4 stiffener, JLC selective solder. Alternate: kinghelm KH-3.0AF180ZJ-11.5JB (C2979037, H 11.5: set CONN_H 11.5)"),
    "HDMI": dict(mpn="HOAUC HYC79-HDMIA19-105", lcsc="C711353", h=10.5, note="HDMI-A 19P vertical, SMD signals + THT shell legs (through the FR4 stiffener), H 10.5 (front shell must be <= 15.4 x 5.6 to pass the flex: verify); HDMI port module"),
    "RJ45": dict(mpn="Lingqiang ZJLQ-RJ45-SMD-PCB125-8P8C (vertical SMD, unshielded, no magnetics, no LED; height not on LCSC page: VERIFY <= 13.0) + JASN V24P05S 2.5G magnetics", lcsc="C55547809 + C2827281", h=12.0,
                 note="D-IO15: non-magnetic vertical RJ45 on the main board + discrete JASN V24P05S (SMD-24P 15.1 x 7.1, 1:1 CT, 180 uH, 1.5 kVrms, IEEE 802.3bz, LCSC $0.63 @10)")}

def zs(x):  # outer surface height at X (0 at the crown)
    u = x - PL_C[0]; return -(CASE_R - math.sqrt(CASE_R ** 2 - u * u))
def zi(x): return zs(x) - SKIN
def d0(x): return zi(x) - Z_BOARD

# ---------------- solid ----------------
BIG = 400.0
def prism(w, h, r, z0=2.0, z1=-20.0):
    return cq.Workplane("XY").workplane(offset=z0).center(*PL_C).sketch().rect(w, h).vertices().fillet(r).finalize().extrude(z1 - z0)
def cyl(rad): return cq.Workplane("XZ").center(PL_C[0], -CASE_R).circle(rad).extrude(BIG, both=True)
def boxz(cx, cy, w, h, r, za, zb):
    return cq.Workplane("XY").workplane(offset=za).center(cx, cy).sketch().rect(w, h).vertices().fillet(max(min(r, w / 2 - 0.01, h / 2 - 0.01), 0.05)).finalize().extrude(zb - za)
R0 = CASE_R
FLEX_POLY = [tuple(p) for p in FJ["outline"]]
def _seg_d(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay; t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-12)))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))
def flex_dist(px, py):   # signed distance to the flex outline (negative inside)
    d = min(_seg_d(px, py, *FLEX_POLY[i], *FLEX_POLY[(i + 1) % len(FLEX_POLY)]) for i in range(len(FLEX_POLY)))
    inside = MPath(FLEX_POLY).contains_point((px, py)) or (NECK[0] <= px <= NECK[2] and NECK[1] <= py <= NECK[3])
    return -d if inside else d
dropped_clips = []; keep = []
if GLUED: CLIPS = []                          # glued plate: every clip removed (stock clip points kept only as documentation in CLIPS_L / CLIP_B)
for x, y, o in CLIPS:
    if (x, y) in CLIPS_L + CLIP_B: keep.append((x, y, o)); continue     # stock clip points always stay (the stock flex lived with them)
    hw, hh = ((CLIP_T + 2 * CLIP_HOOK) / 2, CLIP_W / 2) if o[0] == "x" else (CLIP_W / 2, (CLIP_T + 2 * CLIP_HOOK) / 2)
    dmin = min(flex_dist(x + i * hw, y + j * hh) for i in (-1, 0, 1) for j in (-1, 0, 1))
    (keep if dmin > FLEX_CLR + 0.2 else dropped_clips).append((x, y, o))
CLIPS = keep

plate = prism(PL_W, PL_H, PL_R).intersect(cyl(R0)).cut(cyl(R0 - SKIN))      # constant wall, inner face concentric (one smooth cylinder)
if RIM_H > 0:
    rim = prism(PL_W, PL_H, PL_R).cut(prism(PL_W - 2 * RIM_W, PL_H - 2 * RIM_W, PL_R - RIM_W)).intersect(cyl(R0 - SKIN + 0.02)).cut(cyl(R0 - SKIN - RIM_H))
    plate = plate.union(rim)
report = []
for x, y, o in CLIPS:
    z_ = zi(x)
    if o[0] == "x":
        tab = cq.Workplane("XY").workplane(offset=z_ + 0.3).center(x, y).rect(CLIP_T, CLIP_W).extrude(-(CLIP_L + 0.3))
        hook = cq.Workplane("XY").workplane(offset=z_ - CLIP_L + 1.2).center(x + (-1 if o == "x-" else 1) * (CLIP_T / 2 + CLIP_HOOK / 2), y).rect(CLIP_HOOK, CLIP_W).extrude(-1.2)
    else:
        tab = cq.Workplane("XY").workplane(offset=z_ + 0.3).center(x, y).rect(CLIP_W, CLIP_T).extrude(-(CLIP_L + 0.3))
        hook = cq.Workplane("XY").workplane(offset=z_ - CLIP_L + 1.2).center(x, y - (CLIP_T / 2 + CLIP_HOOK / 2)).rect(CLIP_W, CLIP_HOOK).extrude(-1.2)
    plate = plate.union(tab).union(hook)
for x, y, o in dropped_clips: report.append(("CLIP_DROPPED", "CLIP", x, y, CLIP_T, CLIP_W, "mirrored clip collides with the 821-2222 flex/neck -> removed"))
if SCREW_RELIEF_ON: plate = plate.cut(cq.Workplane("XY").workplane(offset=zi(FRAME_SCREW[0]) - 0.01).center(*FRAME_SCREW).circle(SCREW_POCKET_D / 2).extrude(SCREW_POCKET_DEPTH + 0.01))
# glue pocket (flex outline + FLEX_CLR, FLEX_POCKET into the skin) + neck notch through the rim
fl = cq.Workplane("XY").workplane(offset=-20).polyline(FLEX_POLY).close().offset2D(FLEX_CLR).extrude(22)
fl = fl.union(boxz((NECK[0] + NECK[2]) / 2, (NECK[1] + NECK[3]) / 2, NECK[2] - NECK[0], NECK[3] - NECK[1], 0.3, -20, 2))
if FLEX_POCKET > 0: plate = plate.cut(fl.intersect(cyl(R0 - SKIN + FLEX_POCKET)))
report.append(("FLEX_BOND", "GLUE", PL_C[0], PL_C[1], 0, 0, "821-2222-A PSA-bonded FLAT on the 1.4 inner face (no pocket; was 0.20 deep). Located by the port-plug jig (+-0.2)"))
# clearance pockets for the plate-side parts of the flex (LED chips, button carrier ring)
R_FLEXFACE = R0 - SKIN + FLEX_POCKET - PSA_T          # plate-side face of the flex
R_LEDPOCKET = R_FLEXFACE + LED_H + POCKET_GAP
R_BTNPOCKET = R_FLEXFACE + BTN_CARRIER_H + POCKET_GAP
led_cut = None
for k, l in enumerate(FJ["leds"]):
    b = boxz(l["cx"], l["cy"], l["w"] + 2 * LED_CLR, l["h"] + 2 * LED_CLR, 0.3, -20, 2)
    led_cut = b if led_cut is None else led_cut.union(b)
if PLATE_SIDE_POCKETS:
    plate = plate.cut(led_cut.intersect(cyl(R_LEDPOCKET)))
    plate = plate.cut(cq.Workplane("XY").workplane(offset=-20).center(BTN["cx"], BTN["cy"]).circle(BTN["ring_d"] / 2 + 0.3).extrude(22).intersect(cyl(R_BTNPOCKET)))
if PLATE_SIDE_POCKETS:
    report.append(("LED_POCKETS", "POCKET", 0, 0, 0, 0, "%d pockets (chip + %.2f/side), %.2f above the flex face, wall left %.2f" % (len(FJ["leds"]), LED_CLR, LED_H + POCKET_GAP, R0 - R_LEDPOCKET)))
    report.append(("BTN_CARRIER_POCKET", "POCKET", BTN["cx"], BTN["cy"], BTN["ring_d"] + 0.6, BTN["ring_d"] + 0.6, "carrier pocket"))
else:
    report.append(("NO_POCKETS", "NOTE", 0, 0, 0, 0, "no LED / button-carrier pockets: the mirrored 821-2222 trace puts the %d LEDs and the button carrier on the BOARD side of the flex (inside-face scan to confirm)" % len(FJ["leds"])))
report.append(("NO_CLIPS_NO_RIM", "NOTE", 0, 0, 0, 0, "screwed (glue optional) plate: %d stock clip points + the 3.0 x 1.2 rim removed; edges = the 1.4 wall" % (len(CLIPS_L) * 2 + len(CLIP_B) * 2)))
if not PINS_ON: report.append(("NO_PINS", "NOTE", 0, 0, 0, 0, "Ø2.4 frame pins and button-ear pins removed (1.4 everywhere); align with dummy plugs in the port openings while the glue cures"))
if not SCREW_RELIEF_ON: report.append(("NO_SCREW_RELIEF", "NOTE", FRAME_SCREW[0], FRAME_SCREW[1], 0, 0, "frame centre-screw relief removed: head must stay <= ~1.1 above the frame face (flex 0.12 + PSA 0.05 + foam ~1.0), CHECK M-IOF2"))
# outer spot-faces at the USB-C columns
relief_info = {}
for rid, x, y, w, h, r in RELIEF:
    u_near = min(abs(x - w / 2 - PL_C[0]), abs(x + w / 2 - PL_C[0]))
    zf = -(CASE_R - math.sqrt(CASE_R ** 2 - u_near ** 2)) - (SKIN - MIN_WALL)
    plate = plate.cut(boxz(x, y, w, h, r, zf, 5.0))
    relief_info[rid] = dict(floor_z=round(zf, 3), w=w, h=h, cx=round(x, 3), cy=round(y, 3))
    report.append((rid, "SPOTFACE", x, y, w, h, "flat floor z=%.2f (wall >= %.1f at the inboard edge); USB-C plug overmold relief" % (zf, MIN_WALL)))
R_FLEX = R0 - SKIN + FLEX_POCKET - PSA_T - FLEX_T / 2
def tilt_of(x):
    u = x - PL_C[0]; a = math.asin(u / R_FLEX)
    if TILT_OVERRIDE_DEG is not None: a = math.copysign(math.radians(TILT_OVERRIDE_DEG), u)
    return a
fr = json.load(open(os.path.join(HERE, "..", "..", "bracket", "io_frame", "io_frame.json")))["features"]
# rev ~14:20 ET: the frame scan was registered to the (mirrored) stock port grid (pairs incl. HDMI <-> SMALL_R1), so it is mirrored with the flex
X_MIRROR = FJ.get("mirror", {}).get("x_m")
if X_MIRROR:
    for _k, _f in fr.items():
        if "cx" in _f: _f["cx"] = 2 * X_MIRROR - _f["cx"]
    SLOT = {"USBC_H": "TALL_L", "USBC_O": "TALL_R", "USBA_H": "SQ_L", "USBA_O": "SQ_R", "HDMI": "SMALL_R1", "ETH1": "SMALL_R2"}   # names = scan names (L/R now = -X/+X)
else:
    SLOT = {"USBC_H": "TALL_R", "USBC_O": "TALL_L", "USBA_H": "SQ_R", "USBA_O": "SQ_L", "HDMI": "SMALL_R1", "ETH2": "SMALL_R2"}
R_FB = R_FLEXFACE - FLEX_T; R_FOAM = R_FB - FOAM_T; R_FRB = R_FOAM - FRAME_T
_TG = {}
def tilt_geom(oid, kind, x, y, w):
    """Tilted port: axis direction n at tilt_of(x), through the flex cut-out centre (+ balance shift) at the flex mid-plane.
    Returns mouth plane, recesses, overmold stand-off (with / without seat), per-layer margins of the tilted shell."""
    if oid in _TG: return _TG[oid]
    c = CUT[oid]; side = "H" if x < PL_C[0] else "O"; sw, sh = SHELL[kind]["shell"]; ow, oh = SHELL[kind]["overmold"]
    ang = tilt_of(x); n = (math.sin(ang), math.cos(ang)); ex = (math.cos(ang), -math.sin(ang)); fslot = fr[SLOT[kind + ("" if kind == "HDMI" else "_" + side)]]
    def build(dx):
        u = x - PL_C[0] + dx; P0 = (u, -R0 + math.sqrt(R_FLEX ** 2 - u * u))
        def t_hit(xi, rho):
            qx, qz = P0[0] + xi * ex[0], P0[1] + xi * ex[1] + R0; b = qx * n[0] + qz * n[1]; cc = qx * qx + qz * qz - rho * rho
            return -b + math.sqrt(b * b - cc)
        def span(r_a, r_b):
            pts = []
            for rho in (r_a, r_b):
                for xi in (-sw / 2, sw / 2):
                    t = t_hit(xi, rho); qx, qz = P0[0] + xi * ex[0] + t * n[0], P0[1] + xi * ex[1] + t * n[1] + R0
                    pts.append(PL_C[0] + rho * math.atan2(qx, qz))
            return min(pts), max(pts)
        def marg(sp, lo, hi): return [round(sp[0] - lo, 3), round(hi - sp[1], 3)]
        m = dict(flex=marg(span(R_FLEXFACE, R_FB), c["cx"] - c["w"] / 2, c["cx"] + c["w"] / 2),
                 foam=marg(span(R_FB, R_FOAM), c["cx"] - c["w"] / 2 - 0.3, c["cx"] + c["w"] / 2 + 0.3),
                 frame=marg(span(R_FOAM, R_FRB), fslot["cx"] - fslot["w"] / 2, fslot["cx"] + fslot["w"] / 2))
        return P0, t_hit, m
    dx = 0.0
    if AXIS_BALANCE:
        _, _, m = build(0.0); lo = min(v[0] for v in m.values()); hi = min(v[1] for v in m.values()); dx = round((hi - lo) / 2, 3)
        if abs(dx) < 0.02: dx = 0.0
    dx = round(dx + math.copysign(AXIS_SHIFT_OUT.get(kind, 0.0), x - PL_C[0]), 3)
    P0, t_hit, m = build(dx)
    t_ax = t_hit(0.0, R0); t_m = min(t_hit(xi, R0 - MOUTH_CLR) for xi in (-sw / 2, sw / 2))
    rec_e = [t_hit(xi, R0) - t_m for xi in (-sw / 2, sw / 2)]
    xis = [w / 2 + k * (ow / 2 - w / 2) / 20 for k in range(21)] if ow > w else []
    stand0 = max([0.0] + [t_hit(sg * xi, R0) - t_m for xi in xis for sg in (-1, 1)])
    W = ow + 2 * SEAT_CLR
    t_seat = max(t_m, max(t_hit(sg * xi, R0 - SKIN + SEAT_MIN_WALL) for xi in [w / 2 + k * (W / 2 - w / 2) / 20 for k in range(21)] for sg in (-1, 1)))
    stand = min(stand0, t_seat - t_m) if TILT_SEAT else stand0
    seat_depth = max(0.0, max(t_hit(sg * W / 2, R0) for sg in (-1, 1)) - t_seat)
    g = dict(ang=ang, n=n, ex=ex, P0=P0, dx=dx, t_m=t_m, rec=t_ax - t_m, rec_e=rec_e, stand0=stand0, stand=stand, t_seat=t_seat, seat_w=W, seat_h=oh + 2 * SEAT_CLR,
             seat=(TILT_SEAT and stand0 - stand > 0.02), seat_depth=seat_depth, m=m, sw=sw, sh=sh,
             M=(P0[0] + t_m * n[0], P0[1] + t_m * n[1]), surface_normal=math.asin((x - PL_C[0]) / R_FLEX))
    _TG[oid] = g; return g
for oid, kind, x, y, w, h, r in OPEN:
    if kind in TILT_KINDS:
        tg = tilt_geom(oid, kind, x, y, w); a = tg["ang"]; xs, zf = tg["P0"][0] + PL_C[0], tg["P0"][1]   # axis through the flex cut-out centre (+ balance shift)
        hole = cq.Workplane("XY").box(w, h, 14.0).edges("|Z").fillet(min(r, w / 2 - 0.01, h / 2 - 0.01)).rotate((0, 0, 0), (0, 1, 0), math.degrees(a)).translate((xs, y, zf))
        plate = plate.cut(hole); report.append((oid, kind, x, y, w, h, "straight through-hole along the tilted port axis (%.2f deg, axis shift %+.2f), centred on the flex cut-out at the flex plane" % (math.degrees(a), tg["dx"])))
        if tg["seat"]:   # flat seat perpendicular to the axis, floor at t_seat along the axis
            fx, fz = tg["P0"][0] + tg["t_seat"] * tg["n"][0] + PL_C[0], tg["P0"][1] + tg["t_seat"] * tg["n"][1]
            seat = cq.Workplane("XY").box(tg["seat_w"], tg["seat_h"], 6.0).edges("|Z").fillet(1.0).translate((0, 0, 3.0)).rotate((0, 0, 0), (0, 1, 0), math.degrees(a)).translate((fx, y, fz))
            plate = plate.cut(seat); report.append((oid + "_SEAT", "SEAT", x, y, tg["seat_w"], tg["seat_h"], "flat plug seat perpendicular to the axis, %.2f deep at the high edge, wall >= %.1f" % (tg["seat_depth"], SEAT_MIN_WALL)))
    else:
        plate = plate.cut(boxz(x, y, w, h, r, 10.0, -20.0)); report.append((oid, kind, x, y, w, h, "through the curved skin (no land)"))
for oid, x, y, dd in ROUND:
    plate = plate.cut(cq.Workplane("XY").workplane(offset=10).center(x, y).circle(dd / 2).extrude(-30)); report.append((oid, "ROUND", x, y, dd, dd, "through"))
for wid, x, y, w, h, r in WINDOWS:
    plate = plate.cut(boxz(x, y, w, h, r, 10.0, -20.0)); report.append((wid, "LIGHT_WINDOW", x, y, w, h, "through window over the flex light-guide pad"))
for pid, x, y, dd in (LOCATE_PINS if PINS_ON else []):
    plate = plate.union(cq.Workplane("XY").workplane(offset=zi(x) + 0.3).center(x, y).circle(dd / 2).extrude(-(PIN_LEN + 0.3)).faces("<Z").chamfer(0.3))
    report.append((pid, "PIN", x, y, dd, dd, "locating pin Ø%.1f x %.1f into the frame hole, through the flex hole" % (dd, PIN_LEN)))
for pid, x, y, dd in (EAR_PINS if PINS_ON else []):
    plate = plate.union(cq.Workplane("XY").workplane(offset=zi(x) + FLEX_POCKET + 0.01).center(x, y).circle(dd / 2).extrude(-(EAR_PIN_LEN + FLEX_POCKET)).faces("<Z").chamfer(0.2))
    report.append((pid, "PIN", x, y, dd, dd, "flex locating pin Ø%.1f x %.1f in the button-carrier ear hole Ø1.8" % (dd, EAR_PIN_LEN)))
# ---- power-button area features (rev 2026-10-04 ~12:35 ET, Aidan: build the stock button mounts / plastic features into the plate;
#      rev ~13:05 ET, Aidan: the ring round the button is a RAISED COLLAR on the inner face (aligns the button cap to the flex dome), not a recess) ----
# Evidence: outer-face flatbed scan 83f0b85e (the plate is translucent enough that the inner-face features show; registration offset vs the flex
# trace ~(-0.5, -1.0), so every position below is taken from the 821-2222-A flex trace = what the stock flex needs):
#   * ring band around the Ø11.9 (scan) button hole out to Ø15.1 +-0.3 = the collar (Aidan 12:58 ET: raised), with a lobe at ~140 deg (back view,
#     from +X) reaching r ~9.8 = key tab on the collar;
#   * a "crater" (ring Ø~2.5 around a dark Ø~1.1 core) at BOTH carrier-ear holes (BTN_EAR_1/2, Ø1.8) -> posts with a core through the ear holes;
#   * a straight line at X ~51.2 (flex frame) along the 0.8-wide slot between the carrier ring and the flex body (X 50.83-51.63, Y 102.9-111.2) -> rib.
# No other boss is visible, and no tall boss fits outside the flex (the flex covers the frame BIG_L leg opening; the AC opening is 2.2 above the
# collar), so the ear posts are the retainer mounts (heat-stake or M1.0 thread-forming into the Ø0.8 core). Heights: ASSUMED [M-IOPB*].
BUTTON_FEATURES = "--no-button" not in sys.argv
BTN_FRAME_GAP = PSA_T + FLEX_T + FOAM_T + FLEX_POCKET   # 1.17: inner face -> frame front (same stack as the centre post)
BTN_FLEX_DEPTH = BTN_FRAME_GAP - PSA_T - FLEX_T     # 1.00: plate-side face of the flex button island if it sits back at the frame plane [M-IOPB7]
BTN_COLLAR_CLR = 0.20                               # air gap collar end -> flex island (no preload on the flex / dome)
BTN_COLLAR_H = float(sys.argv[sys.argv.index("--collar-h") + 1]) if "--collar-h" in sys.argv else round(BTN_FLEX_DEPTH - BTN_COLLAR_CLR, 3)   # 0.80 [M-IOPB2]
BTN_COLLAR_OD = 15.0                                # scan ring Ø15.1 +-0.3 [M-IOPB2]
BTN_COLLAR_ID = 12.4                                # = the PWR_BTN opening: one straight bore 1.4 + 0.8 long guiding the cap (our Ø12.0 cap 0.20/side; stock cap
                                                    # <= Ø11.9 from the scan); >= 12.38 keeps the 2 button LEDs inside the bore. Set to cap OD + 0.2 once measured [M-IOPB1]
BTN_KEY_MODE = "tab"                                # "tab" (outward lug, = the scan lobe) | "gap" (keyway slot through the collar wall) | "none" [M-IOPB3]
BTN_KEY_ANG, BTN_KEY_W, BTN_KEY_R0, BTN_KEY_R1 = 140.0, 2.6, 7.0, 9.8   # key: angle (back view), width, radial span (gap mode: r ID/2-0.1 .. OD/2+0.1)
# rev ~15:30 ET (Aidan): the Ø1.6 posts lose their Ø0.8 core in print -> BOSSES the carrier ear lugs sit on, screwed through the Ø1.8 ear holes.
BTN_EAR_MODE = "post" if "--ear-posts" in sys.argv else "boss"   # "boss" (default): Ø3.0 boss, top = flex island plane, M1.4 thread-former pilot | "post": old Ø1.6 pins
BTN_BOSS_OD = 3.0                                  # >= 3 so the pilot survives printing (0.95 wall round a Ø1.1 pilot)
BTN_BOSS_H = float(sys.argv[sys.argv.index("--boss-h") + 1]) if "--boss-h" in sys.argv else None   # default = BTN_FLEX_DEPTH (set below): boss top supports the flex/carrier ear at the island plane
BTN_BOSS_PILOT_D = 1.1                             # M1.4 thread-forming for plastics (pilot 1.0-1.2)
BTN_SCREW = dict(size="M1.4", length=2.5, head_d=2.6, head_k=0.9)   # pan/wafer head on the carrier lug (board side)
BTN_CARRIER_T = 0.4                                # carrier lug thickness behind the flex [ASSUMED, M-IOPB6]
BTN_PILOT_SKIN = 0.5                               # material left under the pilot at the outer face
if BTN_EAR_MODE == "boss":
    BTN_POST_D, BTN_POST_L = BTN_BOSS_OD, None     # length set to BTN_BOSS_H once BTN_FLEX_DEPTH is known
    BTN_POST_CORE_D = BTN_BOSS_PILOT_D
else:
    BTN_POST_D, BTN_POST_L = 1.6, 1.0              # old ear posts: Ø1.6 in the Ø1.8 ear holes (0.10/side), 1.0 below the inner face [M-IOPB4]
    BTN_POST_CORE_D = 0.8
BTN_POST_CORE_DEPTH = None                         # pilot / core depth from the tip, set below (leaves BTN_PILOT_SKIN at the outer face)
if BTN_EAR_MODE == "boss": BTN_POST_L = BTN_BOSS_H if BTN_BOSS_H is not None else round(BTN_FLEX_DEPTH, 3)   # 1.00
BTN_POST_CORE_DEPTH = round(BTN_POST_L + SKIN - BTN_PILOT_SKIN, 3)                                          # 1.90
BTN_RIB = dict(x=51.23, y0=103.3, y1=108.9, t=0.5, h=1.0)   # locating rib in the flex slot (0.15/side); Y end stopped 0.25 short of the old HDMI clamp-post head (50.82, 111.0); post moved to (53.6, 114.35) at 15:50 ET
_BTN_EARS = [(h["id"], h["cx"], h["cy"], h["d"]) for h in FJ["holes"] if h["id"].startswith("BTN_EAR")]
BTN_FEATS = []
def _bplace(wp, x, y):   # radial placement (same as _place below)
    a = math.asin((x - PL_C[0]) / R0)
    return wp.rotate((0, 0, 0), (0, 1, 0), math.degrees(a)).translate((PL_C[0] + R0 * math.sin(a), y, -R0 + R0 * math.cos(a)))
def _btn_key_fp(r0, r1):
    return cq.Workplane("XY").workplane(offset=-20).center(BTN["cx"], BTN["cy"]).transformed(rotate=(0, 0, BTN_KEY_ANG)).center((r0 + r1) / 2, 0) \
        .sketch().rect(r1 - r0, BTN_KEY_W).vertices().fillet(0.4).finalize().extrude(22)
if BUTTON_FEATURES:
    _bx, _by = BTN["cx"], BTN["cy"]; _ka = math.radians(BTN_KEY_ANG)
    # collar = footprint (OD - ID [+ tab]) between the inner face (+0.05 overlap) and the inner face - H, concentric with the plate cylinder (constant height)
    _fp = cq.Workplane("XY").workplane(offset=-20).center(_bx, _by).circle(BTN_COLLAR_OD / 2).extrude(22)
    if BTN_KEY_MODE == "tab": _fp = _fp.union(_btn_key_fp(BTN_KEY_R0, BTN_KEY_R1))
    _fp = _fp.cut(cq.Workplane("XY").workplane(offset=-20).center(_bx, _by).circle(BTN_COLLAR_ID / 2).extrude(22))
    if BTN_KEY_MODE == "gap": _fp = _fp.cut(_btn_key_fp(BTN_COLLAR_ID / 2 - 0.1, BTN_COLLAR_OD / 2 + 0.1))
    plate = plate.union(_fp.intersect(cyl(R0 - SKIN + 0.05)).cut(cyl(R0 - SKIN - BTN_COLLAR_H)))
    _kr = (BTN_KEY_R0 + BTN_KEY_R1) / 2 if BTN_KEY_MODE == "tab" else (BTN_COLLAR_ID + BTN_COLLAR_OD) / 4
    _kx, _ky = _bx + _kr * math.cos(_ka), _by + _kr * math.sin(_ka)
    BTN_FEATS.append(dict(id="BTN_COLLAR", kind="BTN", x=_bx, y=_by, w=BTN_COLLAR_OD, h=BTN_COLLAR_OD, od=BTN_COLLAR_OD, id_=BTN_COLLAR_ID, height=BTN_COLLAR_H,
                          wall=round((BTN_COLLAR_OD - BTN_COLLAR_ID) / 2, 2), flex_depth=round(BTN_FLEX_DEPTH, 3), clr_to_flex=round(BTN_FLEX_DEPTH - BTN_COLLAR_H, 3),
                          clr_to_frame_plane=round(BTN_FRAME_GAP - BTN_COLLAR_H, 3),
                          note="raised collar OD %.1f / ID %.1f x %.2f high (normal to the inner face) round the Ø%.1f button opening: cap guide bore %.2f long; %.2f short of the flex button island at %.2f (frame front %.2f)"
                               % (BTN_COLLAR_OD, BTN_COLLAR_ID, BTN_COLLAR_H, [q for q in ROUND if q[0] == "PWR_BTN"][0][3], SKIN + BTN_COLLAR_H, BTN_FLEX_DEPTH - BTN_COLLAR_H, BTN_FLEX_DEPTH, BTN_FRAME_GAP),
                          conf="raised: confirmed (Aidan); OD medium (scan +-0.3); ID / height assumed"))
    if BTN_KEY_MODE != "none":
        BTN_FEATS.append(dict(id="BTN_KEY", kind="BTN", x=_kx, y=_ky, w=BTN_KEY_W, h=BTN_KEY_W, mode=BTN_KEY_MODE, ang=BTN_KEY_ANG, kw=BTN_KEY_W,
                              r=[BTN_KEY_R0, BTN_KEY_R1] if BTN_KEY_MODE == "tab" else [BTN_COLLAR_ID / 2, BTN_COLLAR_OD / 2], height=BTN_COLLAR_H,
                              note=("key TAB on the collar %.1f wide, r %.1f-%.1f at %.0f deg (back view), collar height" if BTN_KEY_MODE == "tab" else "key GAP (keyway) %.1f wide through the collar wall, r %.1f-%.1f at %.0f deg")
                                   % ((BTN_KEY_W, BTN_KEY_R0, BTN_KEY_R1, BTN_KEY_ANG) if BTN_KEY_MODE == "tab" else (BTN_KEY_W, BTN_COLLAR_ID / 2, BTN_COLLAR_OD / 2, BTN_KEY_ANG)),
                              conf="medium-low (scan lobe only)"))
    for eid, ex_, ey_, ed in _BTN_EARS:
        add = cq.Workplane("XY").workplane(offset=-SKIN + 0.3).circle(BTN_POST_D / 2).extrude(-(BTN_POST_L + 0.3)).faces("<Z").chamfer(0.2 if BTN_EAR_MODE == "post" else 0.25)
        plate = plate.union(_bplace(add, ex_, ey_))
        if BTN_POST_CORE_D > 0:
            core = cq.Workplane("XY").workplane(offset=-SKIN - BTN_POST_L - 0.1).circle(BTN_POST_CORE_D / 2).extrude(BTN_POST_CORE_DEPTH + 0.1)
            if BTN_EAR_MODE == "boss":   # 0.15 x 45 deg lead-in on the pilot
                core = core.union(cq.Workplane("XY").add(cq.Solid.makeCone(BTN_POST_CORE_D / 2 + 0.25, BTN_POST_CORE_D / 2, 0.25, cq.Vector(0, 0, -SKIN - BTN_POST_L - 0.1), cq.Vector(0, 0, 1))))
            plate = plate.cut(_bplace(core, ex_, ey_))
        if BTN_EAR_MODE == "boss":
            BTN_FEATS.append(dict(id="BTN_POST_" + eid[-1], kind="BTN", mode="boss", x=ex_, y=ey_, w=BTN_POST_D, h=BTN_POST_D, length=BTN_POST_L, core=[BTN_POST_CORE_D, BTN_POST_CORE_DEPTH],
                                  ear_hole_d=ed, screw=BTN_SCREW, screw_clr_in_ear_hole=round((ed - 1.4) / 2, 3),
                                  note="ear BOSS Ø%.1f x %.2f (radial; top = flex island plane) under the carrier ear lug; %s x %.1f thread-forming screw through the Ø%.1f ear hole into a Ø%.2f x %.2f pilot (%.1f skin left)"
                                       % (BTN_POST_D, BTN_POST_L, BTN_SCREW["size"], BTN_SCREW["length"], ed, BTN_POST_CORE_D, BTN_POST_CORE_DEPTH, BTN_PILOT_SKIN), conf="position high (flex trace) / size medium / height assumed"))
        else:
            BTN_FEATS.append(dict(id="BTN_POST_" + eid[-1], kind="BTN", mode="post", x=ex_, y=ey_, w=BTN_POST_D, h=BTN_POST_D, length=BTN_POST_L, core=[BTN_POST_CORE_D, BTN_POST_CORE_DEPTH],
                                  ear_hole_d=ed, radial_clr=round((ed - BTN_POST_D) / 2, 3),
                                  note="ear post Ø%.1f x %.1f (radial) through the carrier ear hole Ø%.1f; Ø%.1f x %.1f core = heat-stake core or M1.0 thread-forming pilot for the button retainer" % (BTN_POST_D, BTN_POST_L, ed, BTN_POST_CORE_D, BTN_POST_CORE_DEPTH), conf="position high / size medium"))
    rb = BTN_RIB
    plate = plate.union(boxz(rb["x"], (rb["y0"] + rb["y1"]) / 2, rb["t"], rb["y1"] - rb["y0"], 0.2, zi(rb["x"]) + 0.3, zi(rb["x"]) - rb["h"]))
    BTN_FEATS.append(dict(id="BTN_RIB", kind="BTN", x=rb["x"], y=(rb["y0"] + rb["y1"]) / 2, w=rb["t"], h=rb["y1"] - rb["y0"], length=rb["h"],
                          note="locating rib %.1f x %.1f x %.1f in the 0.8 slot between the carrier ring and the flex body (X 50.83-51.63)" % (rb["t"], rb["y1"] - rb["y0"], rb["h"]), conf="medium-low"))
    for f in BTN_FEATS: report.append((f["id"], "BTN", f["x"], f["y"], f["w"], f["h"], f["note"]))
else:
    report.append(("NO_BUTTON_FEATURES", "NOTE", BTN["cx"], BTN["cy"], 0, 0, "button-area features off (--no-button)"))
SCREW_CHECK = []
# ---- centre screws (rev 2026-10-02 ~16:20 ET, Aidan 16:14 ET: the holes near the plate centre DEFINITELY carry plate->frame screws = PRIMARY fixings;
# the 4 corner M1.6 = secondary). They sit on the flex holes HOLE_C1 (Ø3.3) / HOLE_C2 (Ø5.08), which are the clearance holes the stock posts pass through,
# and on the frame holes HOLE_C1 (Ø3.17) / HOLE_C2 (Ø4.84). Position = midpoint of the flex-hole and (mirrored) frame-hole centres (0.27 / 0.22 apart).
# The plate reaches the frame through a POST standing off the inner face: plate inner face -> PSA 0.05 + flex 0.12 + foam 1.0 = 1.17 -> frame front face
# (frame front at D0_crown 18.0 - 1.17 = 16.83 above the board top, back at 15.83; module model frame_back_height 15.50-15.56 at the port columns).
CENTRE_GAP = PSA_T + FLEX_T + FOAM_T + FLEX_POCKET   # 1.17: post length from the inner face to the frame front face [M-IOC2]
CENTRE_C3 = "--c3" in sys.argv                      # third centre point K11 / PIN_C3 (flex hole Ø5.67, frame Ø3 feature): low confidence -> OFF by default
_fh = {h["id"]: h for h in FJ["holes"]}
def _mid(hid):
    f, m = _fh[hid], fr[hid]; return ((f["cx"] + m["cx"]) / 2, (f["cy"] + m["cy"]) / 2)
# rev 2026-10-04 ~11:15 ET (Aidan, test print; corrects the ~10:30 ET swap): SCR_C2 (lower, HOLE_C2) REMOVED - that is the stock alignment post we
# do not have (flex hole HOLE_C2 left free); SCR_C1 (upper, HOLE_C1, OD 2.6 in the frame hole D3.17, washer D4) KEPT as the centre screw post and
# shortened by CENTRE_TRIM = 1.0 (gap to the frame front 1.17 -> 0.17, post 1.97 -> 0.97 below the inner face). Old C2: ("SCR_C2", HOLE_C2, OD 4.2, washer 6.0)
CENTRE_TRIM = {"SCR_C1": 1.0}
CENTRE_SCREWS = [("SCR_C1", *_mid("HOLE_C1"), 2.6, "HOLE_C1", 4.0)] + \
                ([("SCR_C3", *_mid("PIN_C3"), 2.6, "PIN_C3", 4.0)] if CENTRE_C3 else [])
CENTRE_SCREWS = CENTRE_SCREWS if FIX == "screws" else []
# all screws: (id, x, y, post OD, gap inner face -> frame front, frame hole id, washer Ø, role)
ALL_SCREWS = [(sid, x, y, SPIGOT_OD, CORNER_GAP, None, 4.0, "secondary (corner)") for sid, x, y in SCREWS] + \
             [(sid, x, y, od, CENTRE_GAP - CENTRE_TRIM.get(sid, 0.0), fh, wd, "PRIMARY (centre)") for sid, x, y, od, fh, wd in CENTRE_SCREWS]
def _screw_local(mode, od, gap):
    """post + hole in a local frame: z = 0 on the outer face, -z = radially inward. Returns (add, cut, tip depth)."""
    z_in = -SKIN; z_tip = z_in - gap - SPIGOT_L
    add = cq.Workplane("XY").workplane(offset=z_in + 0.3).circle(od / 2).extrude(z_tip - z_in - 0.3).faces("<Z").chamfer(0.2)
    if 0 < gap and od == SPIGOT_OD and gap == CORNER_GAP: add = add.union(cq.Workplane("XY").workplane(offset=z_in + 0.3).circle(BASE_OD / 2).extrude(-(gap + 0.3)))
    if mode == "csk":
        cut = cq.Workplane("XY").workplane(offset=1.0).circle(SCREW_CLR_D / 2).extrude(z_tip - 1.5)
        rs, rh = SCREW_CSK_D / 2, SCREW_CLR_D / 2
        cut = cut.union(cq.Workplane("XY").add(cq.Solid.makeCone(rs + 0.5, rh, (rs + 0.5 - rh), cq.Vector(0, 0, 0.5), cq.Vector(0, 0, -1))))
    else:
        cut = cq.Workplane("XY").workplane(offset=-SCREW_PT_SKIN).circle(SCREW_PILOT_D / 2).extrude(z_tip - 0.5 + SCREW_PT_SKIN)
        cut = cut.union(cq.Workplane("XY").add(cq.Solid.makeCone(SCREW_PILOT_D / 2 + 0.3, SCREW_PILOT_D / 2, 0.3, cq.Vector(0, 0, z_tip - 0.01), cq.Vector(0, 0, 1))))
    return add, cut, -z_tip
def _place(wp, x, y):
    a = math.asin((x - PL_C[0]) / R0)
    return wp.rotate((0, 0, 0), (0, 1, 0), math.degrees(a)).translate((PL_C[0] + R0 * math.sin(a), y, -R0 + R0 * math.cos(a)))
def _rbox_d(px, py, cx, cy, w, h, r):   # distance from a point to a rounded box (outside > 0)
    dx = max(abs(px - cx) - (w / 2 - r), 0); dy = max(abs(py - cy) - (h / 2 - r), 0); return math.hypot(dx, dy) - r if (dx or dy) else -min(w / 2 - abs(px - cx), h / 2 - abs(py - cy))
def _bb_d(px, py, x0, x1, y0, y1): return math.hypot(max(x0 - px, 0, px - x1), max(y0 - py, 0, py - y1))
_MJ = json.load(open(os.path.join(HERE, "..", "..", "kicad", "macpro62-io-modules", "modules.json"))); _MODS = _MJ["modules"]
_PLC = json.load(open(os.path.join(HERE, "..", "..", "kicad", "macpro62-io-board", "tools", "placement.json")))
_GEO = json.load(open(os.path.join(HERE, "..", "..", "kicad", "macpro62-io-board", "tools", "io_geom.json")))
CLAMP_TOP = max(m["collar_top_height"] for m in _MODS) + _MJ["stack"]["plate_t"]          # module clamp plate top above the board (collar 13.66 + PA12 1.6)
_CLAMP_GRP = {"C": (47.0, 81.0), "A": (24.0, 51.0), "HDMI": (106.0, 117.5)}                  # clamp plate Y spans (posts +-~2.5 / outer rows + rec/2), X ~ 38-68 (README: ~30 wide)
_SPK = _GEO["speaker"]; _COIN = _GEO["coin"]
for sid, x, y, od, gap, fhid, wd, role in ALL_SCREWS:
    add, cut, tipd = _screw_local(SCREW_MODE, od, gap)
    plate = plate.union(_place(add, x, y)).cut(_place(cut, x, y))
    r_out = (SCREW_CSK_D if SCREW_MODE == "csk" else od) / 2; r_in = (BASE_OD if (gap > 0 and fhid is None) else od) / 2
    r_fast = max(wd / 2, 1.85 if SCREW_MODE == "csk" else 1.6)                               # washer / nut corners (3.2 AF) / pan head, below the frame
    edge = -_rbox_d(x, y, PL_C[0], PL_C[1], PL_W, PL_H, PL_R)
    a = math.asin((x - PL_C[0]) / R0); z_o = -R0 + R0 * math.cos(a)
    prot = (0.3 + 1.3 + 0.5) if SCREW_MODE == "csk" else (0.3 + 1.3)                          # below the frame back: washer + nut + tip | washer + pan head
    depth = SKIN + gap + FRAME_T + prot; z_low = z_o - depth * math.cos(a); h_low = z_low - Z_BOARD
    h_frame_back = z_o - (SKIN + gap + FRAME_T) * math.cos(a) - Z_BOARD
    if fhid:   # post passes the flex hole + foam hole and enters the frame hole
        fh_, frh = _fh[fhid], fr[fhid]
        flex = fh_["d"] / 2 - od / 2 - math.hypot(x - fh_["cx"], y - fh_["cy"]); foam = flex + 0.5
        frame = frh["eq_d"] / 2 - od / 2 - math.hypot(x - frh["cx"], y - frh["cy"])
    else:
        flex = flex_dist(x, y) - r_in; foam = flex
        crn = min(((math.hypot(x - v["cx"], y - v["cy"]), k, v["eq_d"]) for k, v in fr.items() if k.startswith("CORNER")))
        frame = None
    neck = _rbox_d(x, y, (NECK[0] + NECK[2]) / 2, (NECK[1] + NECK[3]) / 2, NECK[2] - NECK[0], NECK[3] - NECK[1], 0.3) - r_in
    opn = min([(_rbox_d(x, y, ox, oy, w, h, r) - r_out, oid) for oid, k_, ox, oy, w, h, r in OPEN] + [(math.hypot(x - ox, y - oy) - dd / 2 - r_out, oid) for oid, ox, oy, dd in ROUND] +
              [(_rbox_d(x, y, ox, oy, w, h, r) - r_out, wid) for wid, ox, oy, w, h, r in WINDOWS])
    pads = min([(_rbox_d(x, y, p["cx"], p["cy"], p["w"], p["h"], 0.3) - r_in, p["id"]) for p in FJ["light_pads"]] + [(_rbox_d(x, y, l["cx"], l["cy"], l["w"], l["h"], 0.05) - r_in, "LED@%.1f,%.1f" % (l["cx"], l["cy"])) for l in FJ["leds"]])
    def _mod_d(m):   # receptacle shell / stiffener / paddle / fold plan box of each module vs the fastener footprint below the frame
        xs = [m["stiffener_plan_x"][0], m["stiffener_plan_x"][1], m["paddle_x"][0], m["paddle_x"][1], m["fold_outer_x"]]
        return _bb_d(x, y, min(xs), max(xs), m["y"] - 6.0, m["y"] + 6.0) - r_fast
    mods = min((_mod_d(m), m["slot"]) for m in _MODS)
    shells = min((_bb_d(x, y, m["seat_plan_x"] - SHELL[m["kind"]]["shell"][0] / 2, m["seat_plan_x"] + SHELL[m["kind"]]["shell"][0] / 2, m["y"] - SHELL[m["kind"]]["shell"][1] / 2, m["y"] + SHELL[m["kind"]]["shell"][1] / 2) - r_fast, m["slot"]) for m in _MODS)
    clamp = [g for g, (y0, y1) in _CLAMP_GRP.items() if y0 - r_fast <= y <= y1 + r_fast and 38.0 - r_fast <= x <= 68.0 + r_fast]
    posts = min((math.hypot(x - px_, y - py_) - r_fast - 1.9, "post %s (%.2f,%.2f)" % (g, px_, py_)) for g, pp in _MJ["posts"].items() for px_, py_ in pp)
    named = {}
    for ref in ("J7", "J8", "J31", "BT1", "H13", "J28", "J9"):
        v = _PLC.get(ref)
        if v: named[ref] = dict(side=v["side"], xy=round(_bb_d(x, y, v["xb"][0], v["xb"][1], v["y"][0], v["y"][1]) - r_fast, 2))
    e_ = ((x - (_SPK["oval_x"][0] + _SPK["oval_x"][1]) / 2) / ((_SPK["oval_x"][1] - _SPK["oval_x"][0]) / 2)) ** 2 + ((y - (_SPK["oval_y"][0] + _SPK["oval_y"][1]) / 2) / ((_SPK["oval_y"][1] - _SPK["oval_y"][0]) / 2)) ** 2
    named["SPEAKER"] = dict(side="F", xy=round(_bb_d(x, y, *_SPK["oval_x"], *_SPK["oval_y"]) - r_fast, 2), inside_oval=e_ < 1)
    named["COIN_CELL"] = dict(side="F", xy=round(math.hypot(x - _COIN["c"][0], y - _COIN["c"][1]) - _COIN["d"] / 2 - r_fast, 2))
    board = sorted((round(_bb_d(x, y, *v["xb"], *v["y"]) - r_fast, 2), k) for k, v in _PLC.items() if v["side"] == "F")[:3]
    row = dict(id=sid, role=role, x=round(x, 3), y=round(y, 3), mode=SCREW_MODE, post_od=od, post_len_below_inner_face=round(gap + SPIGOT_L, 2), local_wall=round(SKIN + gap + SPIGOT_L, 2),
               axis_deg=round(math.degrees(a), 2), edge_margin_outer=round(edge - r_out, 2), edge_margin_inner=round(edge - r_in, 2),
               flex_margin=round(flex, 2), foam_margin=round(foam, 2), frame_hole_margin=None if frame is None else round(frame, 2), neck_margin=round(neck, 2),
               nearest_opening=[round(opn[0], 2), opn[1]], light_pad_led_margin=[round(pads[0], 2), pads[1]], module_plan_margin=[round(mods[0], 2), mods[1]], shell_margin=[round(shells[0], 2), shells[1]],
               fastener_r_below_frame=r_fast, frame_back_h=round(h_frame_back, 2), fastener_lowest_h=round(h_low, 2), clamp_plate_top_h=round(CLAMP_TOP, 2), under_clamp_plate=clamp,
               clamp_plate_gap=round(h_low - CLAMP_TOP, 2) if clamp else None, clamp_post_margin=[round(posts[0], 2), posts[1]], named=named, nearest_F_parts=board)
    if fhid is None: row["frame_corner_hole"] = dict(id=crn[1], offset=round(crn[0], 2), d=round(crn[2], 2), note="100 dpi frame trace, mirrored with the flex; MEASURE M-IOS1")
    row["ok_plate"] = row["edge_margin_outer"] >= 0.6 and row["flex_margin"] >= 0.1 and row["neck_margin"] >= 0.3 and row["nearest_opening"][0] >= 1.0 and (frame is None or frame >= 0.05)
    row["needs_clamp_plate_hole"] = ("Ø%.1f clearance hole in the %s clamp plate (fastener reaches %.2f above the board, clamp plate top %.2f)" % (2 * r_fast + 1.0, "/".join(clamp), h_low, CLAMP_TOP)) if clamp and h_low < CLAMP_TOP + 0.2 else None
    row["conflicts"] = [k for k, v in named.items() if v["xy"] < 0 and v["side"] == "F"]
    SCREW_CHECK.append(row)
    report.append((sid, "BOSS", x, y, round(2 * max(r_out, r_in) + 0.2, 2), round(2 * max(r_out, r_in) + 0.2, 2),
                   ("%s: M1.6 countersunk from the OUTER face: 90 deg csk Ø%.2f (dk 3.0 head 0.12 below), Ø%.2f clearance, " % (role, SCREW_CSK_D, SCREW_CLR_D) if SCREW_MODE == "csk" else
                    "%s: M1.6 thread-forming from the frame side: blind pilot Ø%.2f (%.2f skin left on the outer face), " % (role, SCREW_PILOT_D, SCREW_PT_SKIN)) +
                   "post Ø%.1f standing %.2f off the inner face (%.2f to the frame front + %.1f into the frame hole), local wall %.2f; radial axis %.1f deg" % (od, gap + SPIGOT_L, gap, SPIGOT_L, SKIN + gap + SPIGOT_L, math.degrees(a))))
for nm, x, y, w, h in (LEGEND if ETH2_BLANK_RECESS else []):
    plate = plate.cut(boxz(x, y, w, h, 0.5, 10.0, -20.0).intersect(cyl(R0)).cut(cyl(R0 - 0.6)))
tag = "" if ETH2 == "open" else "_eth2blank"
# ---------------- glue lands (inner face, NO added material): band from GLUE_EDGE inside the outline to GLUE_KEEP clear of the flex (+neck)
# and of every opening / window. Bead or VHB die-cut goes here; it bonds the plate to the stock metal I/O frame (Aidan: plate is glued in).
def _wire_pts(w_):
    from OCP.BRepTools import BRepTools_WireExplorer
    from OCP.TopAbs import TopAbs_REVERSED
    ex = BRepTools_WireExplorer(w_.wrapped); pts = []
    while ex.More():
        e = cq.Edge(ex.Current()); n = 2 if e.geomType() == "LINE" else 12
        ts = [i / n for i in range(n)]
        if ex.Current().Orientation() == TopAbs_REVERSED: ts = [1 - t for t in ts]
        pts += [(round(e.positionAt(t).x, 3), round(e.positionAt(t).y, 3)) for t in ts]
        ex.Next()
    return pts
def _glue_lands():
    # perimeter glue band: GLUE_EDGE .. GLUE_EDGE+GLUE_BAND inside the outline (where the plate sits on the frame lip), minus the keep-outs
    def _rr(inset, h):
        return cq.Workplane("XY").center(*PL_C).sketch().rect(PL_W - 2 * inset, PL_H - 2 * inset).vertices().fillet(PL_R - inset).finalize().extrude(h)
    base = _rr(GLUE_EDGE, 1.0).cut(_rr(GLUE_EDGE + GLUE_BAND, 1.0))
    keep = cq.Workplane("XY").workplane(offset=-1).polyline(FLEX_POLY).close().offset2D(GLUE_KEEP).extrude(3.0)
    keep = keep.union(boxz((NECK[0] + NECK[2]) / 2, (NECK[1] + NECK[3]) / 2, NECK[2] - NECK[0] + 2 * GLUE_KEEP, NECK[3] - NECK[1] + 2 * GLUE_KEEP, 0.3, -1, 2))
    for oid, kind, x, y, w, h, r in OPEN: keep = keep.union(boxz(x, y, w + 2 * GLUE_KEEP, h + 2 * GLUE_KEEP, r + GLUE_KEEP, -1, 2))
    for oid, x, y, dd in ROUND: keep = keep.union(cq.Workplane("XY").workplane(offset=-1).center(x, y).circle(dd / 2 + GLUE_KEEP).extrude(3))
    for wid, x, y, w, h, r in WINDOWS: keep = keep.union(boxz(x, y, w + 2 * GLUE_KEEP, h + 2 * GLUE_KEEP, r + GLUE_KEEP, -1, 2))
    for sid, x, y, od, *_ in ALL_SCREWS: keep = keep.union(cq.Workplane("XY").workplane(offset=-1).center(x, y).circle(max(od, BASE_OD if CORNER_GAP > 0 else 0) / 2 + GLUE_KEEP).extrude(3))
    g = base.cut(keep)
    faces = [f for f in g.faces().vals() if abs(f.Center().z) < 1e-6 and abs(f.normalAt().z) > 0.99]
    polys = []
    for f in faces:
        bb = f.BoundingBox()
        if f.Area() < 2.0: continue                        # slivers are not usable lands
        polys.append(dict(area=round(f.Area(), 1), bbox=[round(v, 2) for v in (bb.xmin, bb.ymin, bb.xmax, bb.ymax)],
                          pts=_wire_pts(f.outerWire()), holes=[_wire_pts(w) for w in f.innerWires()]))
    return polys
GLUE = _glue_lands()
def _glue_paths():
    from matplotlib.path import Path as _P
    out = []
    for gl in GLUE:
        vs, cs = [], []
        for ring in [gl["pts"]] + gl["holes"]:
            vs += list(ring) + [ring[0]]; cs += [_P.MOVETO] + [_P.LINETO] * (len(ring) - 1) + [_P.CLOSEPOLY]
        out.append(_P(vs, cs))
    return out
def _glue_widths():
    # land width across X at sampled rows, per side (-X / +X half), mm
    import numpy as _np
    paths = _glue_paths(); res = {}
    for y in (0.0, 15.0, 35.0, 55.0, 75.0, 95.0, 115.0, 140.0):
        xs = _np.arange(PL_C[0] - PL_W / 2, PL_C[0] + PL_W / 2, 0.05)
        ins = _np.zeros(len(xs), bool)
        for pa in paths: ins |= pa.contains_points(_np.c_[xs, _np.full(len(xs), y)])
        lo = ins & (xs < PL_C[0]); hi = ins & (xs >= PL_C[0])
        res[y] = (round(lo.sum() * 0.05, 2), round(hi.sum() * 0.05, 2))
    return res
GLUE_W = _glue_widths()
report.append(("GLUE_LANDS", "GLUE", PL_C[0], PL_C[1], 0, 0, ("OPTIONAL fallback (FIX = %s): " % FIX) + "%d flat glue lands (perimeter band %.1f-%.1f in from the edge, %.1f clear of flex/neck/openings) on the 1.4 inner face, total %.0f mm2; land width -X/+X at Y: %s; no material added" % (
    len(GLUE), GLUE_EDGE, GLUE_EDGE + GLUE_BAND, GLUE_KEEP, sum(gl["area"] for gl in GLUE), ", ".join("%g:%.1f/%.1f" % (y, a, b) for y, (a, b) in GLUE_W.items()))))
tag += TAG
step = os.path.join(HERE, "io_plate_v2_A0%s.step" % tag); stl = os.path.join(HERE, "io_plate_v2_A0%s.stl" % tag)
cq.exporters.export(plate, step); cq.exporters.export(plate, stl, tolerance=0.02, angularTolerance=0.1)
bb = plate.val().BoundingBox()
print("bbox", round(bb.xmin, 2), round(bb.xmax, 2), round(bb.ymin, 2), round(bb.ymax, 2), round(bb.zmin, 2), round(bb.zmax, 2), "vol", round(plate.val().Volume(), 1), "solids", len(plate.solids().vals()))

# ---------------- stack-up: required connector heights (board top -> mouth) ----------------
def u_out(x, hw): return abs(x - PL_C[0]) + hw
def zs_u(u): return -(CASE_R - math.sqrt(CASE_R ** 2 - u * u))
def zface_max(x, hw): return zs_u(u_out(x, hw))      # mouth flush at the outboard shell edge (lowest outer-surface point of the footprint)
def relief_floor_at(x, y):
    for rid, ri in relief_info.items():
        if abs(x - ri["cx"]) <= ri["w"] / 2 and abs(y - ri["cy"]) <= ri["h"] / 2: return ri["floor_z"], rid
    return None, None
STACK = []; TILT_CHECK = []
for oid, kind, x, y, w, h, r in OPEN:
    if kind == "AC": continue
    c = CUT[oid]; side = "H" if x < PL_C[0] else "O"
    if kind in TILT_KINDS:   # tilted riser: axis through the flex cut-out centre at the flex mid-plane; NOT necessarily normal to the plate
        tg = tilt_geom(oid, kind, x, y, w); n = tg["n"]; Mx, Mz = tg["M"]; sw, sh = tg["sw"], tg["sh"]
        hc = CONN_H[kind]; Bx, Bz = Mx - n[0] * hc, Mz - n[1] * hc               # riser top face at the connector centre
        _tc = dict(port=oid, tilt_deg=round(math.degrees(tg["ang"]), 2), surface_normal_deg=round(math.degrees(tg["surface_normal"]), 2),
                   off_normal_deg=round(math.degrees(tg["ang"] - tg["surface_normal"]), 2), axis_shift_x=tg["dx"],
                   flex_margin=tg["m"]["flex"], flex_margin_untilted=round((c["w"] - sw) / 2, 3), flex_margin_y=round((c["h"] - sh) / 2 - abs(y - c["cy"]), 3),
                   foam_margin=tg["m"]["foam"], frame_slot_margin=tg["m"]["frame"], plate_opening_margin=round((w - sw) / 2, 3),
                   overmold_standoff_no_seat=round(tg["stand0"], 2), overmold_standoff=round(tg["stand"], 2), seat=tg["seat"], seat_depth_max=round(tg["seat_depth"], 2))
        TILT_CHECK.append(_tc)
        STACK.append(dict(port=oid, kind=kind, x=round(x, 3), y=round(y, 3), tilt_deg=_tc["tilt_deg"], off_normal_deg=_tc["off_normal_deg"], axis_shift_x=tg["dx"],
                          mouth_centre=[round(Mx + PL_C[0], 3), round(Mz, 3)],
                          mouth_centre_height=round(Mz - Z_BOARD, 2), mouth_recess=round(tg["rec"], 2), mouth_recess_edges=[round(v, 2) for v in tg["rec_e"]],
                          plug_recess=round(tg["stand"], 2), plug_overmold_standoff=round(tg["stand"], 2), d0_at_port=round(d0(x), 3),
                          riser_top_centre=[round(Bx + PL_C[0], 3), round(Bz, 3)], riser_top_height=round(Bz - Z_BOARD, 2), riser_bottom_height=round(Bz - RISER_T[kind] * n[1] - Z_BOARD, 2),
                          conn_h=hc, shell_in_flex_cutout_margin=round(min(tg["m"]["flex"] + [_tc["flex_margin_y"]]), 2), part=PARTS[kind]["mpn"], part_h=PARTS[kind]["h"],
                          required_height=round(Mz - Z_BOARD, 2), riser_needed=None, relief=None,
                          overmold_standoff_no_seat=_tc["overmold_standoff_no_seat"],
                          seat_floor=([[round(tg["P0"][0] + tg["t_seat"] * n[0] + sg * tg["seat_w"] / 2 * tg["ex"][0] + PL_C[0], 3),
                                        round(tg["P0"][1] + tg["t_seat"] * n[1] + sg * tg["seat_w"] / 2 * tg["ex"][1], 3)] for sg in (-1, 1)] if tg["seat"] else None)))
        continue
    if kind in ("USBC", "USBA", "HDMI"):
        sw, sh = SHELL[kind]["shell"]; ow, oh = SHELL[kind]["overmold"]
        z_m = zface_max(x, sw / 2)
        u_in = max(abs(x - PL_C[0]) - ow / 2, 0.0)
        zr, rid = relief_floor_at(x, y)
        z_om = zs_u(u_in) if zr is None else max(zr, zs_u(abs(x - PL_C[0]) + ow / 2))
        req = z_m - Z_BOARD; part = PARTS[kind]
        sm = min((c["w"] - sw) / 2 - abs(x - c["cx"]), (c["h"] - sh) / 2 - abs(y - c["cy"]))
        STACK.append(dict(port=oid, kind=kind, x=round(x, 3), y=round(y, 3), mouth_z=round(z_m, 3), d0_at_port=round(d0(x), 3), required_height=round(req, 2),
                          plug_overmold_stop_z=round(z_om, 3), plug_recess=round(z_om - z_m, 2), relief=rid, shell_in_flex_cutout_margin=round(sm, 2),
                          part=part["mpn"], part_h=part["h"], riser_needed=round(req - part["h"], 2)))
    else:   # RJ45: body cannot pass the frame slot or the flex cut-out -> face behind the frame back plane
        bw, bh = SHELL["RJ45"]["body"]
        z_frame_back = zi_u = zs_u(u_out(x, bw / 2)) - SKIN + FLEX_POCKET - PSA_T - FLEX_T - FOAM_T - FRAME_T
        zf = z_frame_back - 0.3
        pw, ph = SHELL["RJ45"]["plug"]
        sm = min((c["w"] - pw) / 2 - abs(x - c["cx"]), (c["h"] - ph) / 2 - abs(y - c["cy"]))
        STACK.append(dict(port=oid, kind=kind, x=round(x, 3), y=round(y, 3), face_z_max=round(zf, 3), max_height=round(zf - Z_BOARD, 2), plug_in_flex_cutout_margin=round(sm, 2),
                          note="jack body 16.2 x 17.0 cannot pass the frame slot (SMALL_R2 15.6 x 13.0 on the HDMI side / BIG_L leg on the button side) nor the flex cut-out: face >= 0.3 behind the frame back plane",
                          part=PARTS["RJ45"]["mpn"], part_h=PARTS["RJ45"]["h"]))
# HDMI fallback if the receptacle shell does not pass the 5.83 flex cut-out
hd = [s for s in STACK if s["port"] == "HDMI"][0]
hd["fallback_face_behind_flex_max_height"] = round(zs_u(u_out(hd["x"], SHELL["HDMI"]["shell"][0] / 2)) - SKIN + FLEX_POCKET - PSA_T - FLEX_T - 0.1 - Z_BOARD, 2)
for s in STACK: print("STACK", s)
for t in TILT_CHECK: print("TILTCHECK", t)

# ---------------- flex check: shells/plugs vs cut-outs, LEDs vs plate features ----------------
def margins(cx, cy, w, h, c):
    return dict(xm=round((cx - w / 2) - (c["cx"] - c["w"] / 2), 2), xp=round((c["cx"] + c["w"] / 2) - (cx + w / 2), 2),
                ym=round((cy - h / 2) - (c["cy"] - c["h"] / 2), 2), yp=round((c["cy"] + c["h"] / 2) - (cy + h / 2), 2))
THRU = {"USBC": SHELL["USBC"]["shell"], "USBA": SHELL["USBA"]["shell"], "HDMI": SHELL["HDMI"]["shell"], "RJ45": SHELL["RJ45"]["plug"]}
FLEX_CHECK = []
for oid, kind, x, y, w, h, r in OPEN:
    if oid not in CUT: continue
    c = CUT[oid]; tw, th = THRU[kind]
    mt = margins(x, y, tw, th, c); mo = margins(x, y, w, h, c)
    FLEX_CHECK.append(dict(port=oid, flex_cutout=dict(cx=c["cx"], cy=c["cy"], w=c["w"], h=c["h"]), offset=[round(x - c["cx"], 2), round(y - c["cy"], 2)],
                           through=("plug" if kind == "RJ45" else "receptacle shell"), through_size=[tw, th], through_min_margin=min(mt.values()), plate_opening_min_margin=min(mo.values()),
                           boss=None, inner_face="flush (no boss)"))
for aid in ("AUD_H", "AUD_O"):
    c = CUT[aid]; o = [q for q in ROUND if q[0] == aid][0]; off = math.hypot(o[1] - c["cx"], o[2] - c["cy"])
    FLEX_CHECK.append(dict(port=aid, flex_cutout=dict(cx=c["cx"], cy=c["cy"], d=c["d"]), offset=[round(o[1] - c["cx"], 2), round(o[2] - c["cy"], 2)],
                           through="Ø%.1f opening / jack nose (Ø6.0 assumed)" % AUD_D, through_min_margin=round(c["d"] / 2 - AUD_D / 2 - off, 2), jack_nose_margin=round(c["d"] / 2 - 3.0 - off, 2), boss=None, inner_face="flush (no boss)"))
for hid, (pid, px_, py_, pd) in (("HOLE_C1", LOCATE_PINS[0]), ("PIN_C3", LOCATE_PINS[1])):
    hh = [q for q in FJ["holes"] if q["id"] == hid][0]
    FLEX_CHECK.append(dict(port=pid, flex_hole=hh, pin_d=pd, radial_margin=round(hh["d"] / 2 - pd / 2 - math.hypot(px_ - hh["cx"], py_ - hh["cy"]), 2)))
# LEDs against plate features (rectangles grown by LED_CLR; circles by radius)
def rect_hit(l, x, y, w, h, g=0.0):
    return abs(l["cx"] - x) < (l["w"] + w) / 2 + g and abs(l["cy"] - y) < (l["h"] + h) / 2 + g
LED_CHECK = []
feats = [(o[0], o[2], o[3], o[4], o[5]) for o in OPEN] + [(q[0], q[1], q[2], q[3], q[3]) for q in ROUND] + [(q[0], q[1], q[2], q[3], q[4]) for q in WINDOWS] + \
        [(q[0], q[1], q[2], q[3] + 0.6, q[3] + 0.6) for q in LOCATE_PINS + EAR_PINS] + [("FRAME_SCREW_RELIEF", FRAME_SCREW[0], FRAME_SCREW[1], SCREW_POCKET_D, SCREW_POCKET_D)] + \
        [("CLIP", x, y, (CLIP_T + 2 * CLIP_HOOK) if o[0] == "x" else CLIP_W, CLIP_W if o[0] == "x" else CLIP_T + 2 * CLIP_HOOK) for x, y, o in CLIPS] + \
        [("RIM_NECK_NOTCH", (NECK[0] + NECK[2]) / 2, (NECK[1] + NECK[3]) / 2, NECK[2] - NECK[0], NECK[3] - NECK[1])] + \
        [(f["id"], f["x"], f["y"], f["w"], f["h"]) for f in BTN_FEATS if f["id"] != "BTN_COLLAR"]
for k, l in enumerate(FJ["leds"]):
    hits = [f[0] for f in feats if rect_hit(l, f[1], f[2], f[3], f[4], LED_CLR)]
    in_rim = (l["cx"] - l["w"] / 2 < PL_C[0] - PL_W / 2 + RIM_W + 0.3) or (l["cx"] + l["w"] / 2 > PL_C[0] + PL_W / 2 - RIM_W - 0.3)
    rel = [rid for rid, ri in relief_info.items() if rect_hit(l, ri["cx"], ri["cy"], ri["w"], ri["h"], LED_CLR)]
    btn = math.hypot(l["cx"] - BTN["cx"], l["cy"] - BTN["cy"]) < BTN["ring_d"] / 2
    if btn: hits = [h_ for h_ in hits if h_ not in ("PWR_BTN", "BTN_KEY")]   # button LEDs sit under the button cap by design (they light it)
    LED_CHECK.append(dict(led=k, cx=l["cx"], cy=l["cy"], w=l["w"], h=l["h"], conflicts=hits + (["RIM"] if in_rim else []) + rel, in_button_pocket=btn,
                          ok=not (hits or in_rim or rel)))
for row in FLEX_CHECK: print("FLEXCHECK", row)
for row in LED_CHECK:
    if not row["ok"]: print("LED CONFLICT", row)

# ---- button-area checks (plan + height) ----
BTN_CHECK = {}
if BUTTON_FEATURES:
    _bx, _by = BTN["cx"], BTN["cy"]
    _leg = fr["BIG_L"]; _xm = X_MIRROR or 0.0
    LEG_X = sorted([2 * _xm - _leg["x_range_leg"][0], 2 * _xm - _leg["x_range_leg"][1]]) if X_MIRROR else list(_leg["x_range_leg"]); LEG_Y = list(_leg["y_range_leg"])
    TOP_X = sorted([2 * _xm - _leg["x_range_top"][0], 2 * _xm - _leg["x_range_top"][1]]) if X_MIRROR else list(_leg["x_range_top"]); TOP_Y = list(_leg["y_range_top"])
    def _in_frame_open(px, py, rad):   # min distance from a circle to the frame BIG_L opening edge (positive = fully inside the opening)
        d1 = min(px - LEG_X[0], LEG_X[1] - px, py - LEG_Y[0], LEG_Y[1] - py)
        d2 = min(px - TOP_X[0], TOP_X[1] - px, py - TOP_Y[0], TOP_Y[1] - py)
        return round(max(d1, d2) - rad, 2)
    _ac = [o for o in OPEN if o[0] == "AC"][0]; _e2 = [o for o in OPEN if o[0] == "ETH2"]; _hd = [o for o in OPEN if o[0] == "HDMI"][0]
    rp = BTN_COLLAR_OD / 2; ri = BTN_COLLAR_ID / 2; _ka = math.radians(BTN_KEY_ANG)
    _kR = BTN_KEY_R1 if BTN_KEY_MODE == "tab" else rp
    _kc = [(_bx + _kR * math.cos(_ka) + sx_ * BTN_KEY_W / 2 * -math.sin(_ka), _by + _kR * math.sin(_ka) + sx_ * BTN_KEY_W / 2 * math.cos(_ka)) for sx_ in (-1, 1)]
    # rev ~15:50 ET (Aidan): HDMI clamp post H25 moved (50.82, 111.0) -> (53.6, 114.35) (kicad/macpro62-io-board/tools/hdmi_post_search.py). Its head now sits under the
    # frame bar between the HDMI slot and the AC opening, so the clamp screw is a COUNTERSUNK M2 (ISO 7046-1 dk 3.8, k 1.2) flush with the clamp-plate top; `--clamp-head pan` = old ISO 7045 pan head (k 1.6)
    CLAMP_HEAD = sys.argv[sys.argv.index("--clamp-head") + 1] if "--clamp-head" in sys.argv else "csk"
    head_r, head_h = 1.9, (1.6 if CLAMP_HEAD == "pan" else 0.0)   # height of the head above the clamp-plate top
    hp = min(_MJ["posts"]["HDMI"], key=lambda q: math.hypot(q[0] - _bx, q[1] - _by))   # the HDMI clamp post nearest the button
    head_top = CLAMP_TOP + head_h
    _hd_c = math.hypot(hp[0] - _bx, hp[1] - _by); _ux, _uy = (hp[0] - _bx) / _hd_c, (hp[1] - _by) / _hd_c
    _x_near = _bx + min(rp, _hd_c) * _ux                      # collar point nearest the head
    _xr = _bx - BTN["ring_d"] / 2                               # carrier ring -X edge
    def _hdmi_clamp_check():   # rev ~15:50 ET: the moved HDMI clamp post vs ear 1 (M1.4 head + boss), the carrier (ring + ear-1 lug), the clamp-plate edge and the frame
        e1 = [e for e in _BTN_EARS if e[0] == "BTN_EAR_1"][0]; d1 = math.hypot(hp[0] - e1[1], hp[1] - e1[2])
        s_ = BTN_SCREW; m14_r = s_["head_d"] / 2; m14_low = d0(e1[1]) - BTN_POST_L - FLEX_T - BTN_CARRIER_T - s_["head_k"]
        _uu = ((e1[1] - _bx) / math.hypot(e1[1] - _bx, e1[2] - _by), (e1[2] - _by) / math.hypot(e1[1] - _bx, e1[2] - _by)); _la = (_bx + (BTN["ring_d"] / 2 - 0.8) * _uu[0], _by + (BTN["ring_d"] / 2 - 0.8) * _uu[1])
        _dx, _dy = e1[1] - _la[0], e1[2] - _la[1]; _t = max(0, min(1, ((hp[0] - _la[0]) * _dx + (hp[1] - _la[1]) * _dy) / (_dx * _dx + _dy * _dy)))
        lug = math.hypot(hp[0] - _la[0] - _t * _dx, hp[1] - _la[1] - _t * _dy) - head_r - BTN_POST_D / 2
        s1 = fr["SMALL_R1"]; _sx = 2 * _xm - s1["cx"] if X_MIRROR else s1["cx"]
        slot = min(hp[0] - (_sx - s1["w"] / 2), (_sx + s1["w"] / 2) - hp[0], hp[1] - (s1["cy"] - s1["h"] / 2), (s1["cy"] + s1["h"] / 2) - hp[1])
        fo = round(max(_in_frame_open(hp[0], hp[1], head_r), slot - head_r), 2)
        fb = d0(hp[0]) - CENTRE_GAP - FRAME_T; carrier_low = d0(hp[0]) - BTN_FLEX_DEPTH - FLEX_T
        return dict(post=list(hp), was=[50.82, 111.0], head=CLAMP_HEAD + (" M2 ISO 7046-1 dk 3.8 k 1.2, flush with the clamp-plate top" if CLAMP_HEAD == "csk" else " M2 ISO 7045 dk 3.8 k 1.6 on the clamp-plate top"),
                    head_top_above_board=round(head_top, 2), clamp_plate_top=round(CLAMP_TOP, 2),
                    ear1_m14_head=dict(plan=round(d1 - head_r - m14_r, 2), vert=round(m14_low - head_top, 2), m14_head_lowest_above_board=round(m14_low, 2)),
                    ear1_boss=dict(plan=round(d1 - head_r - BTN_POST_D / 2, 2), vert=round(d0(e1[1]) - BTN_POST_L - head_top, 2)),
                    clamp_plate_edge_to_ear1_head=dict(plan=round(d1 - head_r - 0.4 - m14_r, 2), vert=round(m14_low - CLAMP_TOP, 2), note="clamp-plate edge = head r + 0.4 web; keep the plate edge (notch) >= 0.3 from the ear-1 head"),
                    carrier_ring=dict(plan=round(math.hypot(hp[0] - _bx, hp[1] - _by) - BTN["ring_d"] / 2 - head_r, 2), vert_if_island_at_frame_plane=round(carrier_low - BTN_CARRIER_T - head_top, 2)),
                    carrier_ear1_lug=dict(plan=round(lug, 2), note="lug modelled as a 3.0-wide strap from the ring to the ear hole [assumed]"),
                    frame=dict(head_in_opening_margin=fo, frame_back_above_board=round(fb, 2), head_to_frame_back_vert=round(fb - head_top, 2),
                               pan_head_would_be=round(fb - (CLAMP_TOP + 1.6), 2), note="head over frame material (bar between the HDMI slot and the AC opening): needs head top <= frame back - 0.3 -> countersunk"),
                    rib_plan=round(math.hypot(max(abs(hp[0] - BTN_RIB["x"]) - BTN_RIB["t"] / 2, 0), max(hp[1] - BTN_RIB["y1"], 0)) - head_r, 2),
                    other_post=[q for q in _MJ["posts"]["HDMI"] if list(q) != list(hp)][0])
    BTN_CHECK = dict(
        collar=dict(od=BTN_COLLAR_OD, id=BTN_COLLAR_ID, height=BTN_COLLAR_H, wall=round(rp - ri, 2), key=BTN_KEY_MODE, guide_bore_len=round(SKIN + BTN_COLLAR_H, 2),
                    to_AC_opening=round(_rbox_d(_bx, _by, _ac[2], _ac[3], _ac[4], _ac[5], _ac[6]) - rp, 2),
                    to_ETH2_opening=round(_rbox_d(_bx, _by, _e2[0][2], _e2[0][3], _e2[0][4], _e2[0][5], _e2[0][6]) - rp, 2) if _e2 else None,
                    to_HDMI_opening=round(_rbox_d(_bx, _by, _hd[2], _hd[3], _hd[4], _hd[5], _hd[6]) - rp, 2),
                    key_corners_to_AC=round(min(_rbox_d(px_, py_, _ac[2], _ac[3], _ac[4], _ac[5], _ac[6]) for px_, py_ in _kc), 2),
                    key_corners_to_plate_edge=round(min(-_rbox_d(px_, py_, PL_C[0], PL_C[1], PL_W, PL_H, PL_R) for px_, py_ in _kc), 2),
                    key_tab_frame_open_margin=_in_frame_open(_bx + BTN_KEY_R1 * math.cos(_ka), _by + BTN_KEY_R1 * math.sin(_ka), 0) if BTN_KEY_MODE == "tab" else None,
                    collar_frame_open_margin=round(min(_bx - rp - LEG_X[0], LEG_X[1] - _bx - rp, _by - rp - LEG_Y[0]), 2),
                    end_to_frame_plane=round(BTN_FRAME_GAP - BTN_COLLAR_H, 2),
                    flex=dict(ring_r=round(BTN["ring_d"] / 2, 2), od_inside_ring_by=round(BTN["ring_d"] / 2 - rp, 2),
                              island_at_frame_plane=dict(flex_face_depth=round(BTN_FLEX_DEPTH, 2), gap_collar_end_to_flex=round(BTN_FLEX_DEPTH - BTN_COLLAR_H, 2)),
                              flex_glued_flat=dict(flex_face_depth=PSA_T, lift_of_button_island=round(BTN_COLLAR_H - PSA_T, 2), note="if the flex is PSA-bonded flat right up to the button, the collar end lifts the button island by this much: leave the flex unbonded within ~3 mm of the collar"),
                              to_slot_edge_x50_83=round(50.83 - (_bx + rp), 2), to_rib=round(BTN_RIB["x"] - BTN_RIB["t"] / 2 - (_bx + rp), 2)),
                    hdmi_post_head=dict(plan_overlap=round(rp - (_hd_c - head_r), 2), collar_end_above_board=round(d0(_x_near) - BTN_COLLAR_H, 2), head_top=round(head_top, 2),
                                        vertical_clr=round(d0(_x_near) - BTN_COLLAR_H - head_top, 2),
                                        carrier_t_max_if_island_at_frame_plane=round(d0(_bx + (_hd_c - head_r) * _ux) - BTN_FLEX_DEPTH - FLEX_T - head_top, 2),
                                        carrier_t_max_if_flex_flat=round(d0(_bx + (_hd_c - head_r) * _ux) - PSA_T - FLEX_T - head_top, 2)),
                    carrier_minus_x_edge=dict(x=round(_xr, 2), over_frame_in_plan=round(LEG_X[0] - _xr, 2), note="the carrier ring's -X edge lies over frame material: with the island at the frame plane it would bear on the frame")),
        posts=[dict(id="BTN_POST_" + eid[-1], mode=BTN_EAR_MODE, x=ex_, y=ey_, od=BTN_POST_D, height=BTN_POST_L,
                    radial_clr_in_ear_hole=round((ed - BTN_POST_D) / 2, 2) if BTN_EAR_MODE == "post" else None,
                    screw_clr_in_ear_hole=round((ed - 1.4) / 2, 2) if BTN_EAR_MODE == "boss" else None,
                    web_to_collar=round(math.hypot(ex_ - _bx, ey_ - _by) - BTN_POST_D / 2 - rp, 2),
                    fused_to_collar=math.hypot(ex_ - _bx, ey_ - _by) - BTN_POST_D / 2 < rp,
                    pilot_wall=round((BTN_POST_D - BTN_POST_CORE_D) / 2, 2),
                    frame_open_margin=_in_frame_open(ex_, ey_, BTN_POST_D / 2), tip_to_frame_front=round(CENTRE_GAP - BTN_POST_L, 2),
                    tip_above_board=round(d0(ex_) - BTN_POST_L, 2),
                    hdmi_post_head_plan=round(math.hypot(ex_ - hp[0], ey_ - hp[1]) - head_r - BTN_POST_D / 2, 2), hdmi_post_head_vert=round(d0(ex_) - BTN_POST_L - head_top, 2),
                    **(dict(screw=dict(size=BTN_SCREW["size"], length=BTN_SCREW["length"], head_d=BTN_SCREW["head_d"],
                                       engagement=round(BTN_SCREW["length"] - FLEX_T - BTN_CARRIER_T, 2), pilot_depth=BTN_POST_CORE_DEPTH,
                                       head_depth_from_inner_face=[round(BTN_POST_L + FLEX_T + BTN_CARRIER_T, 2), round(BTN_POST_L + FLEX_T + BTN_CARRIER_T + BTN_SCREW["head_k"], 2)],
                                       frame_front_depth=round(CENTRE_GAP, 2), frame_back_depth=round(CENTRE_GAP + FRAME_T, 2),
                                       head_frame_open_margin=_in_frame_open(ex_, ey_, BTN_SCREW["head_d"] / 2),
                                       head_lowest_above_board=round(d0(ex_) - BTN_POST_L - FLEX_T - BTN_CARRIER_T - BTN_SCREW["head_k"], 2),
                                       head_to_hdmi_head_plan=round(math.hypot(ex_ - hp[0], ey_ - hp[1]) - head_r - BTN_SCREW["head_d"] / 2, 2),
                                       head_to_hdmi_head_vert=round(d0(ex_) - BTN_POST_L - FLEX_T - BTN_CARRIER_T - BTN_SCREW["head_k"] - head_top, 2),
                                       carrier_t_assumed=BTN_CARRIER_T)) if BTN_EAR_MODE == "boss" else {}))
               for eid, ex_, ey_, ed in _BTN_EARS],
        rib=dict(slot_margin=[round(BTN_RIB["x"] - BTN_RIB["t"] / 2 - 50.83, 2), round(51.63 - BTN_RIB["x"] - BTN_RIB["t"] / 2, 2)], frame_open_margin=round(min(BTN_RIB["x"] - BTN_RIB["t"] / 2 - LEG_X[0], LEG_X[1] - BTN_RIB["x"] - BTN_RIB["t"] / 2, BTN_RIB["y0"] - LEG_Y[0], LEG_Y[1] - BTN_RIB["y1"]), 2),
                 hdmi_post_head_plan=round(math.hypot(max(abs(hp[0] - BTN_RIB["x"]) - BTN_RIB["t"] / 2, 0), max(hp[1] - BTN_RIB["y1"], 0)) - head_r, 2),
                 tip_to_frame_front=round(CENTRE_GAP - BTN_RIB["h"], 2), tip_above_board=round(d0(BTN_RIB["x"]) - BTN_RIB["h"], 2)),
        button_leds=[dict(cx=l["cx"], cy=l["cy"], far_corner_r=round(math.hypot(abs(l["cx"] - _bx) + l["w"] / 2, abs(l["cy"] - _by) + l["h"] / 2), 2)) for l in FJ["leds"] if math.hypot(l["cx"] - _bx, l["cy"] - _by) < rp],
        other_leds_min_to_collar=round(min(_rbox_d(_bx, _by, l["cx"], l["cy"], l["w"], l["h"], 0.0) - rp for l in FJ["leds"] if math.hypot(l["cx"] - _bx, l["cy"] - _by) >= rp), 2),
        hdmi_clamp=_hdmi_clamp_check(),
        frame_big_l=dict(leg_x=[round(v, 2) for v in LEG_X], leg_y=[round(v, 2) for v in LEG_Y], top_x=[round(v, 2) for v in TOP_X], top_y=[round(v, 2) for v in TOP_Y]))
    BTN_CHECK["button_led_opening_margin"] = round([q for q in ROUND if q[0] == "PWR_BTN"][0][3] / 2 - max(l["far_corner_r"] for l in BTN_CHECK["button_leds"]), 2) if BTN_CHECK["button_leds"] else None
    BTN_CHECK["button_led_collar_bore_margin"] = round(ri - max(l["far_corner_r"] for l in BTN_CHECK["button_leds"]), 2) if BTN_CHECK["button_leds"] else None
    print("BTNCHECK", json.dumps(BTN_CHECK))
# ---------------- trace DXF, foam DXF, check image (ETH2 open build only) ----------------
def rr_pts(cx, cy, w, h, r, n=9):
    r = min(r, w / 2, h / 2); pts = []
    for (ax_, ay_, a0) in ((cx + w / 2 - r, cy + h / 2 - r, 0), (cx - w / 2 + r, cy + h / 2 - r, 90), (cx - w / 2 + r, cy - h / 2 + r, 180), (cx + w / 2 - r, cy - h / 2 + r, 270)):
        for k in range(n):
            t = math.radians(a0 + 90 * k / (n - 1)); pts.append((ax_ + r * math.cos(t), ay_ + r * math.sin(t)))
    return pts
if ETH2 == "open" and not TAG:
    doc = ezdxf.new("R2010"); msp = doc.modelspace()
    for ln, col in (("FLEX_OUTLINE", 30), ("FLEX_CUTOUTS", 30), ("FLEX_HOLES", 30), ("FLEX_LIGHT_PADS", 5), ("FLEX_LEDS", 2), ("FLEX_BUTTON", 6), ("FLEX_TAIL", 8), ("FLEX_CONTACTS", 40),
                    ("FLEX_SILVER_FRAMES", 9), ("IGNORED_BLACK_TAB", 251), ("REF_PLATE_OUTLINE", 7), ("REF_PLATE_OPENINGS", 7), ("REF_LIGHT_WINDOWS", 2), ("REF_LED_POCKETS", 1), ("NOTES", 7)):
        doc.layers.add(ln, color=col)
    def rr(cx, cy, w, h, r, layer): msp.add_lwpolyline(rr_pts(cx, cy, w, h, r), close=True, dxfattribs={"layer": layer})
    msp.add_lwpolyline(FLEX_POLY, close=True, dxfattribs={"layer": "FLEX_OUTLINE"})
    msp.add_lwpolyline([tuple(p) for p in FJ["tail"]], close=True, dxfattribs={"layer": "FLEX_TAIL"})
    ce = FJ["contact_end"]; cc = ce["contacts"]
    for k in range(cc["n"]):
        x0 = (cc["x"][0] + cc["x"][1]) / 2 - (cc["n"] - 1) * cc["pitch"] / 2 + k * cc["pitch"]
        msp.add_lwpolyline([(x0 - 0.15, cc["y"][0]), (x0 + 0.15, cc["y"][0]), (x0 + 0.15, cc["y"][1]), (x0 - 0.15, cc["y"][1])], close=True, dxfattribs={"layer": "FLEX_CONTACTS"})
    it = FJ["ignored_tab"]; rr((it["x"][0] + it["x"][1]) / 2, (it["y"][0] + it["y"][1]) / 2, it["x"][1] - it["x"][0], it["y"][1] - it["y"][0], 0.5, "IGNORED_BLACK_TAB")
    for c in FJ["cutouts"]:
        if "d" in c: msp.add_circle((c["cx"], c["cy"]), c["d"] / 2, dxfattribs={"layer": "FLEX_CUTOUTS"})
        else: rr(c["cx"], c["cy"], c["w"], c["h"], c["r"], "FLEX_CUTOUTS")
        msp.add_text(c["id"], dxfattribs={"layer": "NOTES", "height": 1.0}).set_placement((c["cx"] - 1.5, c["cy"]))
    for hh in FJ["holes"]: msp.add_circle((hh["cx"], hh["cy"]), hh["d"] / 2, dxfattribs={"layer": "FLEX_HOLES"})
    for p in FJ["light_pads"]: rr(p["cx"], p["cy"], p["w"], p["h"], 0.3, "FLEX_LIGHT_PADS"); msp.add_text(p["id"], dxfattribs={"layer": "NOTES", "height": 0.8}).set_placement((p["cx"] - 2, p["cy"] + p["h"] / 2 + 0.3))
    for l in FJ["leds"]: rr(l["cx"], l["cy"], l["w"], l["h"], 0.05, "FLEX_LEDS"); rr(l["cx"], l["cy"], l["w"] + 2 * LED_CLR, l["h"] + 2 * LED_CLR, 0.3, "REF_LED_POCKETS")
    for f in FJ["silver_frames"]: rr(f["cx"], f["cy"], f["w"], f["h"], 0.5, "FLEX_SILVER_FRAMES")
    msp.add_circle((BTN["cx"], BTN["cy"]), BTN["ring_d"] / 2, dxfattribs={"layer": "FLEX_BUTTON"}); msp.add_circle((BTN["cx"], BTN["cy"]), BTN["dome_d"] / 2, dxfattribs={"layer": "FLEX_BUTTON"})
    rr(PL_C[0], PL_C[1], PL_W, PL_H, PL_R, "REF_PLATE_OUTLINE")
    for oid, kind, x, y, w, h, r in OPEN: rr(x, y, w, h, r, "REF_PLATE_OPENINGS")
    for oid, x, y, dd in ROUND: msp.add_circle((x, y), dd / 2, dxfattribs={"layer": "REF_PLATE_OPENINGS"})
    for wid, x, y, w, h, r in WINDOWS: rr(x, y, w, h, r, "REF_LIGHT_WINDOWS")
    msp.add_text("821-2222-A I/O-wall flex trace (plate-facing side, back view, mm) from Aidan flatbed scan 06ea8deb (200 dpi, ruler-calibrated, idealised); +-0.15; VERIFY by caliper",
                 dxfattribs={"layer": "NOTES", "height": 1.6}).set_placement((20, -26))
    doc.saveas(os.path.join(HERE, "flex_821-2222_trace.dxf"))
    # foam / insulator die-cut (board side of the flex): flex outline, minus cut-outs + 0.3, minus holes + 0.5, minus the button ring + 0.5
    doc = ezdxf.new("R2010"); msp = doc.modelspace()
    for ln in ("CUT_OUTER", "CUT_INNER", "NOTES"): doc.layers.add(ln)
    msp.add_lwpolyline(FLEX_POLY, close=True, dxfattribs={"layer": "CUT_OUTER"})
    for c in FJ["cutouts"]:
        if "d" in c: msp.add_circle((c["cx"], c["cy"]), c["d"] / 2 + 0.3, dxfattribs={"layer": "CUT_INNER"})
        else: msp.add_lwpolyline(rr_pts(c["cx"], c["cy"], c["w"] + 0.6, c["h"] + 0.6, c["r"] + 0.3), close=True, dxfattribs={"layer": "CUT_INNER"})
    for hh in FJ["holes"]:
        if not hh["id"].startswith("BTN_EAR"): msp.add_circle((hh["cx"], hh["cy"]), hh["d"] / 2 + 0.5, dxfattribs={"layer": "CUT_INNER"})
        elif BUTTON_FEATURES: msp.add_circle((hh["cx"], hh["cy"]), (BTN_SCREW["head_d"] / 2 + 0.25) if BTN_EAR_MODE == "boss" else (BTN_POST_D / 2 + 0.3), dxfattribs={"layer": "CUT_INNER"})   # foam: clear the ear-screw heads (boss) / ear posts
    msp.add_circle((BTN["cx"], BTN["cy"]), BTN["ring_d"] / 2 + 0.5, dxfattribs={"layer": "CUT_INNER"})
    msp.add_text("MP62 IO flex foam / insulator A0 (back view, mm, scan-based outline): 1.0 PE/PORON foam with PSA (stock-like) OR 0.25 Formex GK-10; laser/die cut; VERIFY against the flex",
                 dxfattribs={"layer": "NOTES", "height": 1.6}).set_placement((20, -12))
    doc.saveas(os.path.join(HERE, "io_flex_foam_insulator_A0.dxf"))
    # check image
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    from matplotlib.patches import Polygon as MPoly, Circle as MCirc, Rectangle as MRect, FancyBboxPatch as FBP
    fig, ax = plt.subplots(figsize=(9.5, 15))
    ax.add_patch(FBP((PL_C[0] - PL_W / 2 + PL_R, PL_C[1] - PL_H / 2 + PL_R), PL_W - 2 * PL_R, PL_H - 2 * PL_R, boxstyle="round,pad=%g" % PL_R, fc="#f4f4f4", ec="k", lw=0.8))
    ax.add_patch(MPoly(FLEX_POLY, fc="#ffd98a", ec="#c07000", lw=0.8))
    ax.add_patch(MPoly([tuple(p) for p in FJ["tail"]], fc="#ffe9b8", ec="#c07000", lw=0.6))
    ax.add_patch(MRect((it["x"][0], it["y"][0]), it["x"][1] - it["x"][0], it["y"][1] - it["y"][0], fc="#dddddd", ec="#888888", ls="--", lw=0.6)); ax.text((it["x"][0] + it["x"][1]) / 2, (it["y"][0] + it["y"][1]) / 2, "black tab\n(ignored)", fontsize=6, ha="center", color="#666666")
    ax.add_patch(MRect((ce["x"][0], ce["y"][0]), ce["x"][1] - ce["x"][0], ce["y"][1] - ce["y"][0], fc="#e0a040", ec="#805000", lw=0.6))
    for c in FJ["cutouts"]:
        ax.add_patch(MCirc((c["cx"], c["cy"]), c["d"] / 2, fc="w", ec="#c07000") if "d" in c else MPoly(rr_pts(c["cx"], c["cy"], c["w"], c["h"], c["r"]), fc="w", ec="#c07000"))
    for hh in FJ["holes"]: ax.add_patch(MCirc((hh["cx"], hh["cy"]), hh["d"] / 2, fc="w", ec="#c07000"))
    for p in FJ["light_pads"]: ax.add_patch(MRect((p["cx"] - p["w"] / 2, p["cy"] - p["h"] / 2), p["w"], p["h"], fc="#b8c8ff", ec="b", lw=0.5))
    for row, l in zip(LED_CHECK, FJ["leds"]): ax.add_patch(MRect((l["cx"] - l["w"] / 2, l["cy"] - l["h"] / 2), l["w"], l["h"], fc="#fff200" if row["ok"] else "#ff3030", ec="k", lw=0.3))
    ax.add_patch(MCirc((BTN["cx"], BTN["cy"]), BTN["ring_d"] / 2, fc="none", ec="m", lw=0.8))
    for k, v in fr.items():
        if k.startswith(("SQ", "TALL", "SMALL", "ROUND", "BIG")): ax.add_patch(MRect((v["cx"] - v["w"] / 2, v["cy"] - v["h"] / 2), v["w"], v["h"], fc="none", ec="g", lw=0.6, ls=":"))
    for oid, kind, x, y, w, h, r in OPEN: ax.add_patch(MPoly(rr_pts(x, y, w, h, r), fc="none", ec="k", lw=0.6))
    for s in STACK:
        if "shell_in_flex_cutout_margin" in s:
            sw, sh = SHELL[s["kind"]]["shell"]; ax.add_patch(MRect((s["x"] - sw / 2, s["y"] - sh / 2), sw, sh, fc="none", ec="r", lw=0.7, ls="--"))
    for oid, x, y, dd in ROUND: ax.add_patch(MCirc((x, y), dd / 2, fc="none", ec="k", lw=0.6))
    for wid, x, y, w, h, r in WINDOWS: ax.add_patch(MRect((x - w / 2, y - h / 2), w, h, fc="#ffff80", ec="k", lw=0.6))
    for pid, x, y, dd in LOCATE_PINS + EAR_PINS: ax.add_patch(MCirc((x, y), dd / 2, fc="#4040ff", ec="k", lw=0.4))
    for f in BTN_FEATS:
        if f["id"] == "BTN_COLLAR":
            ax.add_patch(MCirc((f["x"], f["y"]), f["od"] / 2, fc="none", ec="#0030c0", lw=0.8)); ax.add_patch(MCirc((f["x"], f["y"]), f["id_"] / 2, fc="none", ec="#0030c0", lw=0.6))
        elif f["id"].startswith("BTN_POST"): ax.add_patch(MCirc((f["x"], f["y"]), f["w"] / 2, fc="#4040ff", ec="k", lw=0.4))
        elif f["id"] == "BTN_RIB": ax.add_patch(MRect((f["x"] - f["w"] / 2, f["y"] - f["h"] / 2), f["w"], f["h"], fc="#4040ff", ec="k", lw=0.4))
    for x, y, o in CLIPS: ax.plot(x, y, "b^", ms=6)
    from matplotlib.patches import PathPatch as _PP
    for pa in _glue_paths(): ax.add_patch(_PP(pa, fc="#80ff80", ec="#208020", lw=0.4, alpha=0.35))
    for x, y, o in dropped_clips: ax.plot(x, y, "rx", ms=9, mew=2)
    for sid, x, y, od, *_ in ALL_SCREWS: ax.add_patch(MCirc((x, y), od / 2, fc="#ff9090", ec="r", lw=0.8)); ax.text(x, y + 2.0, sid, fontsize=5, ha="center", color="r")
    for row in FLEX_CHECK:
        if "flex_cutout" not in row: continue
        c = row["flex_cutout"]; st = [s for s in STACK if s["port"] == row["port"]]
        ht = ("\nH %.2f" % st[0]["required_height"]) if st and "required_height" in st[0] else (("\nH<=%.1f" % st[0]["max_height"]) if st else "")
        ax.text(c["cx"], c["cy"] - (1.2 if "d" in c else 0), "%s\n%+.2f%s" % (row["port"], row["through_min_margin"], ht), fontsize=5, ha="center", va="center", color="darkred")
    ax.set_xlim(22, 120); ax.set_ylim(-24, 160); ax.set_aspect("equal"); ax.grid(alpha=0.25)
    ax.set_title("821-2222-A flex (scan trace) vs plate v2 A0, back view, mm.  Inner face flush: no bosses, flex sits flat.\n"
                 "orange = flex, white = flex cut-outs/holes, black = plate openings, red dashed = receptacle shells, green dotted = metal frame slots,\n"
                 "blue pads = light guides, yellow chips = LEDs (red = conflict), yellow = light windows, blue dots = pins.\n"
                 "label: min margin of shell/plug in the flex cut-out, H = required board-top-to-mouth height (RJ45: max)", fontsize=6.5)
    plt.tight_layout(); plt.savefig(os.path.join(HERE, "flex_821-2222_check.png"), dpi=170); plt.close(fig)

# ---------------- DXF (openings, back view and front view), features JSON, previews ----------------
if TAG:
    json.dump(dict(params=dict(case_r=round(CASE_R, 3), tag=TAG, d0=dict(board_top_z=Z_BOARD)), parts=PARTS, tilt=dict(override_deg=TILT_OVERRIDE_DEG, check=TILT_CHECK), button=dict(features=BTN_FEATS, check=BTN_CHECK), stack=STACK, fixing=dict(fix=FIX, mode=SCREW_MODE, screws=SCREW_CHECK)),
              open(os.path.join(HERE, "io_plate_v2_A0%s_features.json" % TAG), "w"), indent=1)
if ETH2 == "open" and not TAG:
    for view in ("backview", "frontview"):
        BW = 101.00496445740619
        fx = (lambda x: x) if view == "backview" else (lambda x: 40 + BW - x)   # front view = KiCad PCB frame x (y kept = Y; KiCad y = 200 - Y)
        doc = ezdxf.new("R2010"); msp = doc.modelspace()
        for ln in ("OUTLINE", "OPENINGS", "LIGHT_WINDOWS", "SPOTFACES", "CLIPS", "PINS", "SCREWS", "SCREW_BOSSES", "GLUE_LANDS_OPTIONAL", "BUTTON_INNER_FEATURES", "NOTES"): doc.layers.add(ln)
        for gl in GLUE:
            for ring in [gl["pts"]] + gl["holes"]: msp.add_lwpolyline([(fx(a_), b_) for a_, b_ in ring], close=True, dxfattribs={"layer": "GLUE_LANDS_OPTIONAL"})
        def rrect(cx, cy, w, h, r, layer): msp.add_lwpolyline([(fx(a), b) for a, b in rr_pts(cx, cy, w, h, r)], close=True, dxfattribs={"layer": layer})
        rrect(PL_C[0], PL_C[1], PL_W, PL_H, PL_R, "OUTLINE")
        for oid, kind, x, y, w, h, r in OPEN:
            rrect(x, y, w, h, r, "OPENINGS"); msp.add_text(oid, dxfattribs={"layer": "NOTES", "height": 1.2}).set_placement((fx(x) - 2, y + h / 2 + 0.6))
        for oid, x, y, dd in ROUND: msp.add_circle((fx(x), y), dd / 2, dxfattribs={"layer": "OPENINGS"})
        for wid, x, y, w, h, r in WINDOWS: rrect(x, y, w, h, r, "LIGHT_WINDOWS")
        for rid, x, y, w, h, r in RELIEF: rrect(x, y, w, h, r, "SPOTFACES")
        for x, y, o in CLIPS: msp.add_circle((fx(x), y), 1.0, dxfattribs={"layer": "CLIPS"})
        for pid, x, y, dd in LOCATE_PINS + EAR_PINS: msp.add_circle((fx(x), y), dd / 2, dxfattribs={"layer": "PINS"})
        for sid, x, y, od, *_ in ALL_SCREWS:
            for dd in ((SCREW_CSK_D, SCREW_CLR_D) if SCREW_MODE == "csk" else (SCREW_PILOT_D,)): msp.add_circle((fx(x), y), dd / 2, dxfattribs={"layer": "SCREWS"})
            msp.add_circle((fx(x), y), od / 2, dxfattribs={"layer": "SCREW_BOSSES"})
            msp.add_text("%s M1.6 %s" % (sid, "csk 90 Ø%.2f / Ø%.2f thru" % (SCREW_CSK_D, SCREW_CLR_D) if SCREW_MODE == "csk" else "pilot Ø%.2f blind" % SCREW_PILOT_D), dxfattribs={"layer": "NOTES", "height": 0.8}).set_placement((fx(x) - 3, y + 2.2))
        for f in BTN_FEATS:
            if f["id"] == "BTN_COLLAR":
                for _d in (f["od"], f["id_"]): msp.add_circle((fx(f["x"]), f["y"]), _d / 2, dxfattribs={"layer": "BUTTON_INNER_FEATURES"})
            elif f["id"] == "BTN_KEY":
                _a = math.radians(BTN_KEY_ANG); _u = (math.cos(_a), math.sin(_a)); _v = (-_u[1], _u[0])
                _pts = [(BTN["cx"] + r_ * _u[0] + s_ * BTN_KEY_W / 2 * _v[0], BTN["cy"] + r_ * _u[1] + s_ * BTN_KEY_W / 2 * _v[1]) for r_, s_ in ((f["r"][0], -1), (f["r"][1], -1), (f["r"][1], 1), (f["r"][0], 1))]
                msp.add_lwpolyline([(fx(a_), b_) for a_, b_ in _pts], close=True, dxfattribs={"layer": "BUTTON_INNER_FEATURES"})
            elif f["id"].startswith("BTN_POST"):
                msp.add_circle((fx(f["x"]), f["y"]), f["w"] / 2, dxfattribs={"layer": "BUTTON_INNER_FEATURES"}); msp.add_circle((fx(f["x"]), f["y"]), BTN_POST_CORE_D / 2, dxfattribs={"layer": "BUTTON_INNER_FEATURES"})
            else: rrect(f["x"], f["y"], f["w"], f["h"], 0.2, "BUTTON_INNER_FEATURES")
        if BTN_FEATS: msp.add_text("BUTTON_INNER_FEATURES (inner face): RAISED collar OD %.1f / ID %.1f x %.2f high + key %s, 2 ear %ss Ø%.1f x %.2f (pilot/core Ø%.2f%s), rib %.1f x %.1f x %.1f" % (BTN_COLLAR_OD, BTN_COLLAR_ID, BTN_COLLAR_H, BTN_KEY_MODE, BTN_EAR_MODE, BTN_POST_D, BTN_POST_L, BTN_POST_CORE_D, (" for " + BTN_SCREW["size"] + " x %.1f thread-forming" % BTN_SCREW["length"]) if BTN_EAR_MODE == "boss" else "", BTN_RIB["t"], BTN_RIB["y1"] - BTN_RIB["y0"], BTN_RIB["h"]), dxfattribs={"layer": "NOTES", "height": 0.9}).set_placement((fx(PL_C[0]) - 30, -19))
        msp.add_text("GLUE_LANDS_OPTIONAL = fallback only (default fixing: 4x M1.6 screws, layer SCREWS)", dxfattribs={"layer": "NOTES", "height": 1.2}).set_placement((fx(PL_C[0]) - 30, -16))
        msp.add_text("MP62 IO plate v2 A0 - %s - mm - Y up = MEG/base end" % view, dxfattribs={"layer": "NOTES", "height": 2}).set_placement((fx(PL_C[0]) - 30, -12))
        doc.saveas(os.path.join(HERE, "io_plate_v2_A0_openings_%s.dxf" % view))
    json.dump(dict(params=dict(outline=dict(centre=PL_C, w=PL_W, h=PL_H, r=PL_R), case_r=round(CASE_R, 3), r_inner=round(R_INNER, 3), skin=SKIN, rim_h=RIM_H, rim_w=RIM_W,
                               d0=dict(crown=D0_CROWN, edge=D0_EDGE, edge_u=D0_EDGE_U, board_top_z=Z_BOARD, note="board top -> plate inner face; 16.5 read at the outer edge of the outermost port columns (Aidan 10:21 ET)"),
                               cover_scan=dict(file="../io_cover_scan/io_cover_scan_check.json", R_inner_fit=101.7, scale=0.931, opening_rms=0.49,
                                               outline_width=52.4, outline_length=160.3, verdict="2D layout confirmed (+-0.5); R 100-110 consistent; ends, clips, pins, wall below resolution -> geometry unchanged"),
                               clip=dict(t=CLIP_T, w=CLIP_W, l=CLIP_L, hook=CLIP_HOOK), port_grid=dict(usbc_x=[XH, XO], source="flex 821-2222-A cut-out centres (scan)"),
                               flex=dict(flex_t=FLEX_T, psa_t=PSA_T, foam_t=FOAM_T, frame_t=FRAME_T, pocket=FLEX_POCKET, pocket_clr=FLEX_CLR, neck_notch=NECK, led_h=LED_H, led_clr=LED_CLR,
                                         btn_carrier_h=BTN_CARRIER_H, inner_face="smooth cylinder (1.4) except the screw posts and the button-area features")),
                   button=dict(features=BTN_FEATS, check=BTN_CHECK),
                   parts=PARTS, tilt=dict(override_deg=TILT_OVERRIDE_DEG, source="M-IOT2 Aidan 2026-10-02 11:47 ET: outward 12.5 deg, mirrored" if TILT_OVERRIDE_DEG else "surface normal (D-IO16 default: full plug seating; stock 12.5 in io_plate_v2_A0_tilt12p5_features.json)", mouth_clr=MOUTH_CLR, axis_balance=AXIS_BALANCE, axis_shift_out=AXIS_SHIFT_OUT, seat=TILT_SEAT, seat_clr=SEAT_CLR, seat_min_wall=SEAT_MIN_WALL, check=TILT_CHECK), stack=STACK, spotfaces=relief_info, flex_check=FLEX_CHECK, led_check=LED_CHECK,
                   features=[dict(id=a, kind=b, x=round(c, 3), y=round(d, 3), w=e, h=f, note=g) for a, b, c, d, e, f, g in report], clips=CLIPS,
                   fixing=dict(fix=FIX, mode=SCREW_MODE, screws=SCREW_CHECK, glue_optional=dict(layer="GLUE_LANDS_OPTIONAL", lands=len(GLUE), area_mm2=round(sum(gl['area'] for gl in GLUE), 0)))),
              open(os.path.join(HERE, "io_plate_v2_A0_features.json"), "w"), indent=1)
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, Circle
    fig, ax = plt.subplots(figsize=(6, 13))
    ax.add_patch(FancyBboxPatch((PL_C[0] - PL_W / 2 + PL_R, PL_C[1] - PL_H / 2 + PL_R), PL_W - 2 * PL_R, PL_H - 2 * PL_R, boxstyle="round,pad=%g" % PL_R, fc="#dddddd", ec="k"))
    for rid, x, y, w, h, r in RELIEF: ax.add_patch(FancyBboxPatch((x - w / 2 + r, y - h / 2 + r), w - 2 * r, h - 2 * r, boxstyle="round,pad=%g" % r, fc="#c8c8c8", ec="#777777", ls="--"))
    for oid, tg in _TG.items():
        if tg["seat"]:
            cx_ = tg["P0"][0] + tg["t_seat"] * tg["n"][0] + PL_C[0]; cy_ = CUT[oid]["cy"]; sw_, sh_ = tg["seat_w"] * math.cos(tg["ang"]), tg["seat_h"]
            ax.add_patch(FancyBboxPatch((cx_ - sw_ / 2 + 1.0, cy_ - sh_ / 2 + 1.0), sw_ - 2.0, sh_ - 2.0, boxstyle="round,pad=1.0", fc="#cfc4e6", ec="m", ls="--", lw=0.6))
    for oid, kind, x, y, w, h, r in OPEN:
        ax.add_patch(FancyBboxPatch((x - w / 2 + r, y - h / 2 + r), w - 2 * r, h - 2 * r, boxstyle="round,pad=%g" % r, fc="white", ec="k"))
        ax.text(x, y, oid, ha="center", va="center", fontsize=6)
    for oid, x, y, dd in ROUND: ax.add_patch(Circle((x, y), dd / 2, fc="white", ec="k"))
    ax.text(BTN["cx"], BTN["cy"], "button\n(cap on the\nflex dome)", ha="center", va="center", fontsize=5)
    for wid, x, y, w, h, r in WINDOWS: ax.add_patch(FancyBboxPatch((x - w / 2 + r, y - h / 2 + r), w - 2 * r, h - 2 * r, boxstyle="round,pad=%g" % r, fc="yellow", ec="k"))
    for x, y, o in CLIPS: ax.plot(x, y, "b^", ms=5)
    for sid, x, y, *_ in ALL_SCREWS:
        ax.add_patch(Circle((x, y), SCREW_CSK_D / 2, fc="#ff9090", ec="r", lw=0.8)); ax.add_patch(Circle((x, y), SCREW_CLR_D / 2, fc="white", ec="r", lw=0.5)); ax.text(x, y - 2.6, sid, ha="center", fontsize=5, color="r")
    from matplotlib.patches import PathPatch as _PP
    for pa in _glue_paths(): ax.add_patch(_PP(pa, fc="#80ff80", ec="#208020", lw=0.4, alpha=0.45))
    ax.set_xlim(20, 86); ax.set_ylim(-8, 162); ax.set_aspect("equal"); ax.grid(alpha=0.2)
    ax.set_title("IO plate v2 A0 (1.4 wall, 1x M1.6 centre SCR_C1 (primary, C2 removed) + 4x corner screws (+1.0 Y, 2026-10-04), no clips/rim), OUTER face (back view)\nred = M1.6 csk screw holes, yellow = light windows, green = OPTIONAL inner-face glue lands, violet = flat plug seats; USB-C/USB-A/HDMI holes along the port-module axes (%s)" % ("%.1f deg" % TILT_OVERRIDE_DEG if TILT_OVERRIDE_DEG else "normal to the plate"), fontsize=8)
    plt.tight_layout(); plt.savefig(os.path.join(HERE, "io_plate_v2_A0_outer.png"), dpi=150); plt.close(fig)
    iso = plate.translate((-PL_C[0], -PL_C[1], 0)).rotate((0, 0, 0), (0, 0, 1), 90).rotate((0, 0, 0), (1, 0, 0), 180)
    cq.exporters.export(iso, os.path.join(HERE, "_iso.svg"), opt={"projectionDir": (0.25, -0.45, 1.0), "showHidden": False, "width": 1600, "height": 700,
                                                                 "marginLeft": 40, "marginTop": 40, "strokeWidth": 0.15})
for row in report: print(row)
for row in SCREW_CHECK: print("SCREW", json.dumps(row))
